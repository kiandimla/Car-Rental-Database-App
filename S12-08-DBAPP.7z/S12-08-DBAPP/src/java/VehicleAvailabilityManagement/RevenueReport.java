/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VehicleAvailabilityManagement;

/**
 *
 * @author Janell Megan Ang
 */

import java.sql.*;
import java.util.ArrayList;

public class RevenueReport {
     
    public String vehicletype;
    public Double revenue;
    public int year;
    public int month;
    public int day;
    public Double totalrevenue;
    public Date rentalstartdate;
    
    public String vehicletypeString;
    public String revenueString;
    public String yearString;
    public String monthString;
    public String dayString;

    public ArrayList<Double> revenuelist = new ArrayList<>();
    public ArrayList<String> vehicletypelist = new ArrayList<>();
    public ArrayList<Date> startdatelist = new ArrayList<>();
    public ArrayList<Date> enddatelist = new ArrayList<>();
    public ArrayList<String> makelist = new ArrayList<>();
    public ArrayList<String> modellist = new ArrayList<>();
    
    public RevenueReport() {}
  
    public int GenerateRevenueReport(String vehicletypeString, String revenueString, String yearString, String monthString, String dayString) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            PreparedStatement stmt = null;
            ResultSet rst = null;
            boolean success = false;
            
            // Clear the lists before executing the query
            vehicletypelist.clear();
            startdatelist.clear();
            enddatelist.clear();
            revenuelist.clear();
            makelist.clear();
            modellist.clear();
            

            StringBuilder query = new StringBuilder("SELECT * FROM rentalreservations r JOIN vehicle v ON r.vehicleid = v.vehicleid WHERE 1=1");

                    if (vehicletypeString != null && !vehicletypeString.isEmpty()) {
                        query.append(" AND v.type = ?");}
                
                    if (yearString != null && !yearString.isEmpty()) {
                        query.append(" AND YEAR(r.rentalstartdate) = ?");
                    }

                    if (monthString != null && !monthString.isEmpty()) {
                        query.append(" AND MONTH(r.rentalstartdate) = ?");
                    }

                    if (dayString != null && !dayString.isEmpty()) {
                        query.append(" AND DAY(r.rentalstartdate) = ?");
                    }
                    
                    if (revenueString != null && !revenueString.isEmpty()) {
                        if (vehicletypeString == null && yearString == null && monthString == null && dayString == null){
                            if (revenueString.equalsIgnoreCase("high")) {
                                query.append(" ORDER BY r.totalcost DESC");
                            } else if (revenueString.equalsIgnoreCase("low")) {
                                query.append(" ORDER BY r.totalcost ASC");
                            }
                        } else if (vehicletypeString != null || yearString != null || monthString != null || dayString != null){
                                if (revenueString.equalsIgnoreCase("high")) {
                                    query.append(" ORDER BY r.totalcost DESC LIMIT 1");
                                } else if (revenueString.equalsIgnoreCase("low")) {
                                    query.append(" ORDER BY r.totalcost ASC LIMIT 1");
                                }
                            } 
                        } else {
                        query.append(" ORDER BY v.type, v.make, v.model");
                    }

            stmt = conn.prepareStatement(query.toString());

            int parameterIndex = 1;
            if (vehicletypeString != null && !vehicletypeString.isEmpty()) {
                stmt.setString(parameterIndex++, vehicletypeString);
            }
            
            if (yearString != null && !yearString.isEmpty()) {
                stmt.setInt(parameterIndex++, Integer.parseInt(yearString));
            }

            if (monthString != null && !monthString.isEmpty()) {
                stmt.setInt(parameterIndex++, Integer.parseInt(monthString));
            }

            if (dayString != null && !dayString.isEmpty()) {
                stmt.setInt(parameterIndex++, Integer.parseInt(dayString));
            }
            
            rst = stmt.executeQuery();

            while (rst.next()) {
                vehicletypelist.add(rst.getString("v.type"));
                startdatelist.add(rst.getDate("r.rentalstartdate"));
                enddatelist.add(rst.getDate("r.rentalenddate"));
                revenuelist.add(rst.getDouble("r.totalcost"));
                makelist.add(rst.getString("v.make"));
                modellist.add(rst.getString("v.model"));
                success = true;
            }

            stmt.close();
            conn.close();

            if (success) {
                System.out.println("Successful");
                return 1;
            } else {
                System.out.println("Failed");
                return 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
}