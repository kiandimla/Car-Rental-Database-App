package VehicleAvailabilityManagement;

import java.util.*;
import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;

public class VehicleAvailability {
    
    public int availabilityid;
    public int vehicleid;
    public Date startdate;
    public Date enddate;
    public Double locx;
    public Double locy;
    public String editfield;
    public String dateOption;
    public int year = 0;
    public int month= 0;
    public int day= 0;

    public String listoptions;

    public String vehicleidString;
    public String startdateString;
    public String enddateString;
    public String locxString;
    public String locyString;

    public String yearString;
    public String monthString;
    public String dayString;
   
    public ArrayList<Integer> availabilityidlist  = new ArrayList<> ();
    public ArrayList<Integer> vehicleidlist  = new ArrayList<> ();
    public ArrayList<Date> startdatelist = new ArrayList<> ();
    public ArrayList<Date> enddatelist  = new ArrayList<> ();
    public ArrayList<Double> locxlist = new ArrayList<> ();
    public ArrayList<Double> locylist = new ArrayList<> ();
    
    public VehicleAvailability() {}

    public int getavailability(int availabilityid) {
         try {
            Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            
        try {
            Connection conn;
            boolean success = false;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");      
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM vehicleavailability WHERE availabilityid = ?");
            pstmt.setInt(1,availabilityid);
            ResultSet resultSet = pstmt.executeQuery();
            
            availabilityidlist.clear();
            vehicleidlist.clear();
            startdatelist.clear();
            enddatelist.clear();
            locxlist.clear();
            locylist.clear();
            
            while (resultSet.next()) {
                    availabilityidlist.add(resultSet.getInt("availabilityid"));
                    vehicleidlist.add(resultSet.getInt("vehicleid"));
                    startdatelist.add(resultSet.getDate("startdate"));
                    enddatelist.add(resultSet.getDate("enddate"));
                    locxlist.add(resultSet.getDouble("locx"));
                    locylist.add(resultSet.getDouble("locy"));
                    success = true;
                }
            
            pstmt.close();
            conn.close();
            
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int getAvailabilityIdFromVehicle(int vehicleid) {
    try {
        Class.forName("com.mysql.jdbc.Driver");
    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    }

    try {
        Connection conn;
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
        System.out.println("Connection Successful");

        PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM vehicleavailability WHERE vehicleid = ?");
        pstmt.setInt(1, vehicleid);
        ResultSet resultSet = pstmt.executeQuery();
        
        availabilityidlist.clear();
        vehicleidlist.clear();
        startdatelist.clear();
        enddatelist.clear();
        locxlist.clear();
        locylist.clear();
        
        boolean success = false;
        int availabilityId = -1;

        while (resultSet.next()) {
            availabilityidlist.add(resultSet.getInt("availabilityid"));
            vehicleidlist.add(resultSet.getInt("vehicleid"));
            startdatelist.add(resultSet.getDate("startdate"));
            enddatelist.add(resultSet.getDate("enddate"));
            locxlist.add(resultSet.getDouble("locx"));
            locylist.add(resultSet.getDouble("locy"));
            availabilityId = resultSet.getInt("availabilityid");
            success = true;
        }

        pstmt.close();
        conn.close();

        if (success) {
            System.out.println("Successful");
            return availabilityId; 
        } else {
            System.out.println("Failed");
            return 0;
        }

    } catch (Exception e) {
        System.out.println(e.getMessage());
        return 0; 
    }
}

    public int getlatestvehicleavailability() {
         try {
            Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

        try {
           Connection conn;
           boolean success = false;
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
           System.out.println("Connection Successful");
           
           PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM vehicleavailability WHERE availabilityid = (SELECT MAX(availabilityid) FROM vehicleavailability)");
           ResultSet resultSet = pstmt.executeQuery();
           
            availabilityidlist.clear();
            vehicleidlist.clear();
            startdatelist.clear();
            enddatelist.clear();
            locxlist.clear();
            locylist.clear();
            
            while (resultSet.next()) {
                    availabilityidlist.add(resultSet.getInt("availabilityid"));
                    vehicleidlist.add(resultSet.getInt("vehicleid"));
                    startdatelist.add(resultSet.getDate("startdate"));
                    enddatelist.add(resultSet.getDate("enddate"));
                    locxlist.add(resultSet.getDouble("locx"));
                    locylist.add(resultSet.getDouble("locy"));
                    success = true;
                }
           
           pstmt.close();
           conn.close();
           
           if (success == true) {
               System.out.println("Successful");
               return 1;
           }
           else {
               System.out.println("Failed");
               return 0;
           }
           
       } catch (Exception e) {
           System.out.println(e.getMessage());
           return 0;
       }
   }
    
    public static boolean checkavailabilityidexists(int availabilityid) {
            Connection conn = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            boolean exists = false;
                
            try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
                
             try {
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
    
                // Define the SQL query to check if the vehcile ID exists within a record
                String sql = ("SELECT COUNT(*) FROM vehicleavailability WHERE availabilityid = ?");
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, availabilityid);
    
                // Execute the query
                rs = pstmt.executeQuery();
    
                // Check if any records were found
                if (rs.next()) {
                    int count = rs.getInt(1);
                    exists = (count > 0); 
                }
            } catch (SQLException e) {
                e.printStackTrace();
                
            } finally {
                try {
                    if (rs != null) {
                        rs.close();
                    }
                    if (pstmt != null) {
                        pstmt.close();
                    }
                    if (conn != null) {
                        conn.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
    
            return exists;
        }

    public static boolean checkvehicleidexists(int vehicleid) {
            Connection conn = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            boolean exists = false;
    
            try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
            try {
                
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
    
                // Define the SQL query to check if the vehcile ID exists
                String sql = ("SELECT COUNT(*) FROM vehicle WHERE vehicleid = ?");
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, vehicleid);
    
                // Execute the query
                rs = pstmt.executeQuery();
    
                // Check if any records were found
                if (rs.next()) {
                    int count = rs.getInt(1);
                    exists = (count > 0); 
                }
            } catch (SQLException e) {
                e.printStackTrace();
                
            } finally {
                try {
                    if (rs != null) {
                        rs.close();
                    }
                    if (pstmt != null) {
                        pstmt.close();
                    }
                    if (conn != null) {
                        conn.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
    
            return exists;
        }
    
    public static boolean checkrecordidexists(int vehicleid) {
            Connection conn = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            boolean exists = false;
    
            try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
            try {
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
    
                // Define the SQL query to check if the vehcile ID exists within a record
                String sql = ("SELECT COUNT(*) FROM vehicleavailability WHERE vehicleid = ?");
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, vehicleid);
    
                // Execute the query
                rs = pstmt.executeQuery();
    
                // Check if any records were found
                if (rs.next()) {
                    int count = rs.getInt(1);
                    exists = (count > 0); 
                }
            } catch (SQLException e) {
                e.printStackTrace();
                
            } finally {
                try {
                    if (rs != null) {
                        rs.close();
                    }
                    if (pstmt != null) {
                        pstmt.close();
                    }
                    if (conn != null) {
                        conn.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
    
            return exists;
        }
    
    public static boolean checkRentalDates(int vehicleid) {
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    boolean exists = false;

    try {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");

        LocalDate currentDate = LocalDate.now();

        // Define the SQL query to check if the current date is within the rental dates
        String sql = "SELECT 1 FROM rentalreservations WHERE vehicleid = ? AND ? BETWEEN rentalstartdate AND rentalenddate";
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, vehicleid);
        pstmt.setDate(2, Date.valueOf(currentDate));

        // Execute the query
        rs = pstmt.executeQuery();

        // If any record is found, set exists to true
        exists = rs.next();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return exists;
    }

    public int AddVehicleAvailabilityRecord() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678"); 
            System.out.println("Success");
            
            PreparedStatement stmt = conn.prepareStatement("SELECT MAX(availabilityid) + 1 AS newID FROM vehicleavailability");
            ResultSet rst = stmt.executeQuery();

                while (rst.next()) {
                    availabilityid = rst.getInt("newID");
                }

            stmt = conn.prepareStatement("INSERT INTO vehicleavailability VALUES (?, ?, ?, ?, ?, ?) "); 
            stmt.setInt(1,availabilityid);
            stmt.setInt(2,vehicleid);
            stmt.setDate(3,startdate);
            stmt.setDate(4,enddate);
            stmt.setDouble(5,locx);
            stmt.setDouble(6,locy);

            stmt.executeUpdate();

            stmt.close();
            conn.close();

            return 1;
            } catch (Exception e) {
                System.out.println(e.getMessage());
                return 0;
            }
        }
    
    public int DeleteVehicleAvailabilityRecord() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
            try {
                int status = 0;
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
                System.out.println("Connection Successful");
                
                PreparedStatement stmt = conn.prepareStatement("DELETE FROM vehicleavailability WHERE availabilityid = ?");
                stmt.setInt(1,availabilityid);

                status = stmt.executeUpdate();

                stmt.close();
                conn.close();

                if (status > 0) {
                    System.out.println("Successful");
                    return 1;
                }
                else {
                    System.out.println("Failed");
                    return 0;
                }

                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    return 0;
                }
        }

    public int FilterVehicleAvailabilityRecord(String dateOption, String yearString, String monthString, String dayString) {
    try {
        Class.forName("com.mysql.jdbc.Driver");
    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    }
    
    try {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
        PreparedStatement stmt = null;
        ResultSet rst = null;
        boolean success = false;
        
        // Clear the lists before executing the query
        availabilityidlist.clear();
        vehicleidlist.clear();
        startdatelist.clear();
        enddatelist.clear();
        locxlist.clear();
        locylist.clear();

        StringBuilder query = new StringBuilder("SELECT * FROM vehicleavailability WHERE 1=1");

        if ("start".equals(dateOption) || "end".equals(dateOption)) {
            if ("start".equals(dateOption)) { 
                // Filter by start date
                
                if (yearString != null && !yearString.isEmpty()) {
                    query.append(" AND YEAR(startdate) = ?");
                }

                if (monthString != null && !monthString.isEmpty()) {
                    query.append(" AND MONTH(startdate) = ?");
                }

                if (dayString != null && !dayString.isEmpty()) {
                    query.append(" AND DAY(startdate) = ?");
                }
            } else if ("end".equals(dateOption)) {
                // Filter by end date
                
                if (yearString != null && !yearString.isEmpty()) {
                    query.append(" AND YEAR(enddate) = ?");
                }

                if (monthString != null && !monthString.isEmpty()) {
                    query.append(" AND MONTH(enddate) = ?");
                }

                if (dayString != null && !dayString.isEmpty()) {
                    query.append(" AND DAY(enddate) = ?");
                }
            }
        }

        query.append(" ORDER BY availabilityid, vehicleid");

        stmt = conn.prepareStatement(query.toString());

        int parameterIndex = 1;
        if (yearString != null && !yearString.isEmpty()) {
            stmt.setInt(parameterIndex++, Integer.parseInt(yearString));
        }

        if (monthString != null && !monthString.isEmpty()) {
            stmt.setInt(parameterIndex++, Integer.parseInt(monthString));
        }

        if (dayString != null && !dayString.isEmpty()) {
            stmt.setInt(parameterIndex++, Integer.parseInt(dayString));
        }

        rst = stmt.executeQuery();

          while (rst.next()) {
                availabilityidlist.add(rst.getInt("availabilityid"));
                vehicleidlist.add(rst.getInt("vehicleid"));
                startdatelist.add(rst.getDate("startdate"));
                enddatelist.add(rst.getDate("enddate"));
                locxlist.add(rst.getDouble("locx"));
                locylist.add(rst.getDouble("locy"));
                success = true;
            }

            stmt.close();
            conn.close();

            if (success) {
                System.out.println("Successful");
                return 1;
            } else {
                System.out.println("Failed");
                return 0;
            }
    } catch (Exception e) {
        e.printStackTrace();
        return 0;
    }
}

    public int ListVehicleAvailabilityRecord() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
            try {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
                System.out.println("Connection Successful");
        
                PreparedStatement pstmt = null;
                ResultSet rst = null;
                boolean success = false;
        
                this.availabilityidlist.clear();
                this.vehicleidlist.clear();
                this.startdatelist.clear();
                this.enddatelist.clear();
                this.locxlist.clear();
                this.locylist.clear();
        
                switch (this.listoptions) {
                    case "listbyASCavailabilityid":
                        pstmt = conn.prepareStatement("SELECT * FROM vehicleavailability ORDER BY availabilityid ASC");
                        rst = pstmt.executeQuery();
                        while (rst.next()) {
                            this.availabilityidlist.add(rst.getInt("availabilityid"));
                            this.vehicleidlist.add(rst.getInt("vehicleid"));
                            this.startdatelist.add(rst.getDate("startdate"));
                            this.enddatelist.add(rst.getDate("enddate"));
                            this.locxlist.add(rst.getDouble("locx"));
                            this.locylist.add(rst.getDouble("locy"));
                            success = true;
                        }
                        break;
        
                    case "listbyDESCavailabilityid":
                        pstmt = conn.prepareStatement("SELECT * FROM vehicleavailability ORDER BY availabilityid DESC");
                        rst = pstmt.executeQuery();
                        while (rst.next()) {
                            this.availabilityidlist.add(rst.getInt("availabilityid"));
                            this.vehicleidlist.add(rst.getInt("vehicleid"));
                            this.startdatelist.add(rst.getDate("startdate"));
                            this.enddatelist.add(rst.getDate("enddate"));
                            this.locxlist.add(rst.getDouble("locx"));
                            this.locylist.add(rst.getDouble("locy"));
                            success = true;
                        }
                        break;
        
                    case "listbyASCvehicleid":
                        pstmt = conn.prepareStatement("SELECT * FROM vehicleavailability ORDER BY vehicleid ASC");
                        rst = pstmt.executeQuery();
                        while (rst.next()) {
                            this.availabilityidlist.add(rst.getInt("availabilityid"));
                            this.vehicleidlist.add(rst.getInt("vehicleid"));
                            this.startdatelist.add(rst.getDate("startdate"));
                            this.enddatelist.add(rst.getDate("enddate"));
                            this.locxlist.add(rst.getDouble("locx"));
                            this.locylist.add(rst.getDouble("locy"));
                            success = true;
                        }
                        break;
        
                    case "listbyDESCvehicleid":
                        pstmt = conn.prepareStatement("SELECT * FROM vehicleavailability ORDER BY vehicleid DESC");
                        rst = pstmt.executeQuery();
                        while (rst.next()) {
                            this.availabilityidlist.add(rst.getInt("availabilityid"));
                            this.vehicleidlist.add(rst.getInt("vehicleid"));
                            this.startdatelist.add(rst.getDate("startdate"));
                            this.enddatelist.add(rst.getDate("enddate"));
                            this.locxlist.add(rst.getDouble("locx"));
                            this.locylist.add(rst.getDouble("locy"));
                            success = true;
                        }
                        break;
        
                    case "listbyASCstartdate":
                        pstmt = conn.prepareStatement("SELECT * FROM vehicleavailability ORDER BY startdate ASC");
                        rst = pstmt.executeQuery();
                        while (rst.next()) {
                            this.availabilityidlist.add(rst.getInt("availabilityid"));
                            this.vehicleidlist.add(rst.getInt("vehicleid"));
                            this.startdatelist.add(rst.getDate("startdate"));
                            this.enddatelist.add(rst.getDate("enddate"));
                            this.locxlist.add(rst.getDouble("locx"));
                            this.locylist.add(rst.getDouble("locy"));
                            success = true;
                        }
                        break;
        
                    case "listbyDESCstartdate":
                        pstmt = conn.prepareStatement("SELECT * FROM vehicleavailability ORDER BY startdate DESC");
                        rst = pstmt.executeQuery();
                        while (rst.next()) {
                            this.availabilityidlist.add(rst.getInt("availabilityid"));
                            this.vehicleidlist.add(rst.getInt("vehicleid"));
                            this.startdatelist.add(rst.getDate("startdate"));
                            this.enddatelist.add(rst.getDate("enddate"));
                            this.locxlist.add(rst.getDouble("locx"));
                            this.locylist.add(rst.getDouble("locy"));
                            success = true;
                        }
                        break;
                }
        
                pstmt.close();
                conn.close();
                if (success) {
                    System.out.println("Successful");
                    return 1;
                } else {
                    System.out.println("Failed");
                    return 0;
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
                return 0;
            }
        }

    public int SearchVehicleAvailabilityRecord() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        try {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678"); 
                PreparedStatement stmt = null;
                ResultSet rst = null;
                boolean success = false;

                availabilityidlist.clear();
                vehicleidlist.clear();
                startdatelist.clear();
                enddatelist.clear();
                locxlist.clear();
                locylist.clear();

                StringBuilder query = new StringBuilder("SELECT * FROM vehicleavailability WHERE 1=1");

                if (vehicleidString != null && !vehicleidString.isEmpty()) {
                    vehicleid = Integer.parseInt(vehicleidString);
                    vehicleidlist.clear();
                    query.append(" AND vehicleid = ?");
                }
                if (startdateString != null && !startdateString.isEmpty()) {
                    startdate = java.sql.Date.valueOf(startdateString);
                    startdatelist.clear();
                    query.append(" AND startdate = ?");
                }
                if (enddateString != null && !enddateString.isEmpty()) {
                    enddate = java.sql.Date.valueOf(enddateString);
                    enddatelist.clear();
                    query.append(" AND enddate = ?");
                }
                 if (locxString != null && !locxString.isEmpty()) {
                    locx = Double.parseDouble(locxString);
                    locxlist.clear();
                    query.append(" AND locx = ? ");
                }
                 if (locyString != null && !locyString.isEmpty()) {
                    locy = Double.parseDouble(locyString);
                    locylist.clear();
                    query.append(" AND locy = ? ");
                }

                query.append(" ORDER BY availabilityid");

                stmt = conn.prepareStatement(query.toString());

                int parameterIndex = 1;
                if (vehicleidString != null && !vehicleidString.isEmpty()) {
                    stmt.setInt(parameterIndex++, vehicleid);
                }        
                if (startdateString != null && !startdateString.isEmpty()) {
                    stmt.setDate(parameterIndex++, startdate);
                }
                if (enddateString != null && !enddateString.isEmpty()) {
                    stmt.setDate(parameterIndex++, enddate);
                }
                if (locxString != null && !locxString.isEmpty()) {
                    stmt.setDouble(parameterIndex++, locx);
                }
                if (locyString != null && !locyString.isEmpty()) {
                    stmt.setDouble(parameterIndex++, locy);
                }
                rst = stmt.executeQuery();
                
                while (rst.next()) {
                    availabilityidlist.add(rst.getInt("availabilityid"));
                    vehicleidlist.add(rst.getInt("vehicleid"));
                    startdatelist.add(rst.getDate("startdate"));
                    enddatelist.add(rst.getDate("enddate"));
                    locxlist.add(rst.getDouble("locx"));
                    locylist.add(rst.getDouble("locy"));
                    success = true;
                }
        
                stmt.close();
                conn.close();

                if (success == true) {
                    System.out.println("Successful");
                    return 1;
                }
                else {
                    System.out.println("Failed");
                    return 0;
                }

            } catch (Exception e) {
                e.printStackTrace();
                return 0;
            }
    }
    
    public int UpdateVehicleAvailabilityRecord() {
    try {
        Class.forName("com.mysql.jdbc.Driver");
    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    }

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678")) {
        System.out.println("Connection Successful");

        
        String updateQuery = "UPDATE vehicleavailability SET startdate = ?, enddate = ?, locx = ?, locy = ? WHERE availabilityid = ?";
        try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
            updateStmt.setDate(1, startdate);
            updateStmt.setDate(2, enddate);
            updateStmt.setDouble(3, locx);
            updateStmt.setDouble(4, locy);
            updateStmt.setInt(5, availabilityid);

            int updateStatus = updateStmt.executeUpdate();

            if (updateStatus > 0) {
                System.out.println("Update Successful");
                return 1;
            } else {
                System.out.println("No records updated");
                return 0;
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }
}

    public int ViewVehicleAvailability(int availabilityid) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            boolean success = false;
    
            availabilityidlist.clear();
            vehicleidlist.clear();
            startdatelist.clear();
            enddatelist.clear();
            locxlist.clear();
            locylist.clear();
    
            String query = "SELECT * FROM vehicleavailability WHERE availabilityid = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, availabilityid);
            ResultSet rst = stmt.executeQuery();
    
            while (rst.next()) {
                this.availabilityidlist.add(rst.getInt("availabilityid"));
                this.vehicleidlist.add(rst.getInt("vehicleid"));
                this.startdatelist.add(rst.getDate("startdate"));
                this.enddatelist.add(rst.getDate("enddate"));
                this.locxlist.add(rst.getDouble("locx"));
                this.locylist.add(rst.getDouble("locy"));
                success = true;
            }
    
            stmt.close();
            conn.close();
    
            if (success == true) {
                System.out.println("Successful");
                return 1;
            } else {
                System.out.println("Failed");
                return 0;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }   
    
}
