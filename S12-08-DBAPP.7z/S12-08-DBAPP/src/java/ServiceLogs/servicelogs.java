/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServiceLogs;

/**
 *
 * @author ccslearner
 */

import java.util.*;
import java.sql.*;
import java.sql.Date;
import java.util.Calendar;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class servicelogs {
    public int    servicelogid;
    public int    vehicleid;
    public String servicedescription;
    public int    mileage;
    public double cost;
    public String servicedate;
    public String servicestatus;
    public String registrationno;
    public int    ownerdriverid;
    public String type;
    public String make;
    public String model;
    public int    seatingcapacity;
    public String availabilitystatus;
    public String rentalstartdate;
    public String rentalenddate;
    public String vehicleavailabilityenddate;
    public String updatefield;
    public int    availabilityid;
    public int    dateflagservice = 0;
    public int    dateflagrental = 0;
    
    
    public ArrayList<Integer> servicelogidlist = new ArrayList<>();
    public ArrayList<Integer> vehicleidlist = new ArrayList<>();
    public ArrayList<String> servicedescriptionlist = new ArrayList<>();
    public ArrayList<Integer> mileagelist = new ArrayList<>();
    public ArrayList<Double> costlist = new ArrayList<>();
    public ArrayList<String> servicedatelist = new ArrayList<>();
    public ArrayList<String> servicestatuslist = new ArrayList<>();
    public ArrayList<String> registrationnolist = new ArrayList<>();
    public ArrayList<Integer> ownerdriveridlist = new ArrayList<>();
    public ArrayList<String> typelist = new ArrayList<>();
    public ArrayList<String> makelist = new ArrayList<>();
    public ArrayList<String> modellist = new ArrayList<>();
    public ArrayList<Integer> seatingcapacitylist = new ArrayList<>();
    public ArrayList<String> availabilitystatuslist = new ArrayList<>();
    
    public servicelogs() {}
    
    public int searchservicelog() {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            PreparedStatement pstmt = null;
            ResultSet resultSet = null;
            boolean success = false;
            
            servicelogidlist.clear();
            vehicleidlist.clear();
            servicedescriptionlist.clear();
            mileagelist.clear();
            costlist.clear();
            servicedatelist.clear();
            servicestatuslist.clear();
            
            StringBuilder query = new StringBuilder("SELECT * FROM servicelogs WHERE 1=1");

            if (servicedescription != null && !servicedescription.isEmpty()) {
                query.append(" AND servicedescription LIKE ?");
            }
            if (mileage > 0) {
                query.append(" AND mileage LIKE ?");
            }
            if (cost > 0.0) {
                query.append(" AND cost LIKE ?");
            }
            if (servicedate != null && !servicedate.isEmpty()) {
                query.append(" AND servicedate LIKE ?");
            }
            if (servicestatus != null && !servicestatus.isEmpty()) {
                query.append(" AND servicestatus LIKE ?");
            }
            
            query.append(" ORDER BY servicelogid");
            
            pstmt = conn.prepareStatement(query.toString());

            int parameterIndex = 1;
            if (servicedescription != null && !servicedescription.isEmpty()) {
                pstmt.setString(parameterIndex++, "%" + servicedescription + "%");
            }
            if (mileage > 0) {
                pstmt.setString(parameterIndex++, "%" + mileage + "%");
            }
            if (cost > 0.0) {
                pstmt.setString(parameterIndex++, "%" + cost + "%");
            }
            if (servicedate != null && !servicedate.isEmpty()) {
                pstmt.setString(parameterIndex++, "%" + servicedate + "%");
            }
            if (servicestatus != null && !servicestatus.isEmpty()) {
                pstmt.setString(parameterIndex, "%" + servicestatus + "%");
            }

            resultSet = pstmt.executeQuery();
                
                while (resultSet.next()) {
                    servicelogidlist.add(resultSet.getInt("servicelogid"));
                    vehicleidlist.add(resultSet.getInt("vehicleid"));
                    servicedescriptionlist.add(resultSet.getString("servicedescription"));
                    mileagelist.add(resultSet.getInt("mileage"));
                    costlist.add(resultSet.getDouble("cost"));
                    servicedatelist.add(resultSet.getString("servicedate"));
                    servicestatuslist.add(resultSet.getString("servicestatus"));
                    success = true;
                }
            
            pstmt.close();
            conn.close();
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int getservicelog() {
        try {
            Connection conn;
            boolean success = false;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM servicelogs WHERE servicelogid = ?");
            pstmt.setInt(1,servicelogid);
            ResultSet resultSet = pstmt.executeQuery();
            
            servicelogidlist.clear();
            vehicleidlist.clear();
            servicedescriptionlist.clear();
            mileagelist.clear();
            costlist.clear();
            servicedatelist.clear();
            servicestatuslist.clear();
            
            while (resultSet.next()) {
                    servicelogidlist.add(resultSet.getInt("servicelogid"));
                    vehicleidlist.add(resultSet.getInt("vehicleid"));
                    servicedescriptionlist.add(resultSet.getString("servicedescription"));
                    mileagelist.add(resultSet.getInt("mileage"));
                    costlist.add(resultSet.getDouble("cost"));
                    servicedatelist.add(resultSet.getString("servicedate"));
                    servicestatuslist.add(resultSet.getString("servicestatus"));
                    success = true;
                }
            
            pstmt.close();
            conn.close();
            
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int getpendingservicelog() {
        try {
            Connection conn;
            boolean success = false;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM servicelogs WHERE servicelogid = ? AND servicestatus = 'Pending'");
            pstmt.setInt(1,servicelogid);
            ResultSet resultSet = pstmt.executeQuery();
            
            servicelogidlist.clear();
            vehicleidlist.clear();
            servicedescriptionlist.clear();
            mileagelist.clear();
            costlist.clear();
            servicedatelist.clear();
            servicestatuslist.clear();
            
            while (resultSet.next()) {
                    servicelogidlist.add(resultSet.getInt("servicelogid"));
                    vehicleidlist.add(resultSet.getInt("vehicleid"));
                    servicedescriptionlist.add(resultSet.getString("servicedescription"));
                    mileagelist.add(resultSet.getInt("mileage"));
                    costlist.add(resultSet.getDouble("cost"));
                    servicedatelist.add(resultSet.getString("servicedate"));
                    servicestatuslist.add(resultSet.getString("servicestatus"));
                    success = true;
                }
            
            pstmt.close();
            conn.close();
            
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int getlatestservicelog() {
        try {
            Connection conn;
            boolean success = false;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM servicelogs WHERE servicelogid = (SELECT MAX(servicelogid) FROM servicelogs)");
            ResultSet resultSet = pstmt.executeQuery();
            
            servicelogidlist.clear();
            vehicleidlist.clear();
            servicedescriptionlist.clear();
            mileagelist.clear();
            costlist.clear();
            servicedatelist.clear();
            servicestatuslist.clear();
            
            while (resultSet.next()) {
                    servicelogidlist.add(resultSet.getInt("servicelogid"));
                    vehicleidlist.add(resultSet.getInt("vehicleid"));
                    servicedescriptionlist.add(resultSet.getString("servicedescription"));
                    mileagelist.add(resultSet.getInt("mileage"));
                    costlist.add(resultSet.getDouble("cost"));
                    servicedatelist.add(resultSet.getString("servicedate"));
                    servicestatuslist.add(resultSet.getString("servicestatus"));
                    success = true;
                }
            
            pstmt.close();
            conn.close();
            
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int updateservicelogs() {
        
        try {
            Connection conn;
            int rowsAffected = 0, count = 0, count2 = 0;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(*) AS count FROM rentalreservations WHERE (? BETWEEN rentalstartdate AND rentalenddate) AND vehicleid = ?");
            pstmt.setString(1,servicedate);
            pstmt.setInt(2, vehicleidlist.get(0));
            ResultSet rst = pstmt.executeQuery();
            
            while (rst.next()) {
                count = rst.getInt("count");
            }
            
            if(count == 0) {
            pstmt = conn.prepareStatement(
                "UPDATE servicelogs SET " +
                "servicedescription = ?, " +
                "mileage = ?, " +
                "cost = ?, " +
                "servicedate = ?, " +
                "servicestatus = ? " +
                "WHERE servicelogid = ? AND servicestatus = 'Pending'");
            pstmt.setString(1, servicedescription);
            pstmt.setInt(2, mileage);
            pstmt.setDouble(3, cost);
            pstmt.setString(4,servicedate);
            if (servicestatus == null || servicestatus.isEmpty()) {
                pstmt.setString(5, servicestatus);
            } else {
                pstmt.setString(5, servicestatus);
            }
            pstmt.setInt(6,servicelogid);
            rowsAffected = pstmt.executeUpdate();
            
            if(servicedate != null && !servicedate.isEmpty() && count == 0){
                LocalDate todayservice = LocalDate.now();
                    String formattedDate = todayservice.format(DateTimeFormatter.ISO_LOCAL_DATE);
                    
                    pstmt = conn.prepareStatement("SELECT vehicleid FROM servicelogs WHERE servicelogid = ?");
                    pstmt.setInt(1,servicelogid);
                    rst = pstmt.executeQuery();
                        
                    if (rst.next()) {
                        vehicleid = rst.getInt("vehicleid");
                    }
                    
                    if(formattedDate.equals(servicedate)){
                        pstmt = conn.prepareStatement("DELETE FROM vehicleavailability WHERE vehicleid = ?");
                        pstmt.setInt(1,vehicleid);
                        pstmt.executeUpdate();
                
                        pstmt = conn.prepareStatement("UPDATE vehicle SET availabilitystatus = 'In Service' WHERE vehicleid = ?");
                        pstmt.setInt(1,vehicleid);
                        pstmt.executeUpdate();
                    } else {
                        pstmt = conn.prepareStatement("UPDATE vehicle SET availabilitystatus = 'Available' WHERE vehicleid = ? AND availabilitystatus = 'In Service'");
                        pstmt.setInt(1,vehicleid);
                        pstmt.executeUpdate();
                        
                        pstmt = conn.prepareStatement("SELECT MAX(availabilityid) + 1 AS newavailabilityid FROM vehicleavailability");
                        rst = pstmt.executeQuery();
                        
                        while (rst.next()) {
                            availabilityid = rst.getInt("newavailabilityid");
                        }
                        
                        Calendar calendar = Calendar.getInstance();
                        Date today = new Date(calendar.getTimeInMillis());
                        calendar.set(Calendar.MONTH, Calendar.DECEMBER);
                        calendar.set(Calendar.DAY_OF_MONTH, 31);
                        
                        double locX = Math.random() * 10;
                        double locY = Math.random() * 10;

                        locX = Math.floor(locX * 10) / 10;
                        locY = Math.floor(locY * 10) / 10;

                        
                        pstmt = conn.prepareStatement("INSERT INTO vehicleavailability VALUES (?,?,?,?,?,?)");
                        pstmt.setInt(1,availabilityid);
                        pstmt.setInt(2,vehicleid);
                        pstmt.setDate(3,today);
                        pstmt.setString(4,servicedate);
                        pstmt.setDouble(5,locX);
                        pstmt.setDouble(6,locY);
                        rowsAffected += pstmt.executeUpdate();
                    }
            }
            
                if(servicestatus != null && !servicestatus.isEmpty() && count == 0 && (servicestatus.equals("Completed") || servicestatus.equals("Cancelled"))){
                    pstmt = conn.prepareStatement("SELECT vehicleid FROM servicelogs WHERE servicelogid = ?");
                        pstmt.setInt(1,servicelogid);
                        rst = pstmt.executeQuery();
                        
                        if (rst.next()) {
                            vehicleid = rst.getInt("vehicleid");
                        }
                        
                        pstmt = conn.prepareStatement("UPDATE vehicle SET availabilitystatus = 'Available' WHERE vehicleid = ? AND availabilitystatus = 'In Service'");
                        pstmt.setInt(1,vehicleid);
                        pstmt.executeUpdate();
                        
                        pstmt = conn.prepareStatement("SELECT COUNT(*) AS count FROM vehicleavailability WHERE vehicleid = ?");
                        pstmt.setInt(1,vehicleid);
                        rst = pstmt.executeQuery();
                        
                        if (rst.next()) {
                            count2 = rst.getInt("count");
                        }
                        
                        if(count2 == 0){
                            pstmt = conn.prepareStatement("SELECT MAX(availabilityid) + 1 AS newavailabilityid FROM vehicleavailability");
                            rst = pstmt.executeQuery();
                        
                            while (rst.next()) {
                                availabilityid = rst.getInt("newavailabilityid");
                            }
                        
                            Calendar calendar = Calendar.getInstance();
                            Date today = new Date(calendar.getTimeInMillis());
                            calendar.set(Calendar.MONTH, Calendar.DECEMBER);
                            calendar.set(Calendar.DAY_OF_MONTH, 31);
                            Date endOfYear = new Date(calendar.getTimeInMillis());
                        
                            double locX = Math.random() * 10;
                            double locY = Math.random() * 10;

                            locX = Math.floor(locX * 10) / 10;
                            locY = Math.floor(locY * 10) / 10;

                        
                            pstmt = conn.prepareStatement("INSERT INTO vehicleavailability VALUES (?,?,?,?,?,?)");
                            pstmt.setInt(1,availabilityid);
                            pstmt.setInt(2,vehicleid);
                            pstmt.setDate(3,today);
                            pstmt.setDate(4,endOfYear);
                            pstmt.setDouble(5,locX);
                            pstmt.setDouble(6,locY);
                            rowsAffected += pstmt.executeUpdate();
                        }
                } 
            }
            pstmt.close();
            conn.close();
            
            if (rowsAffected > 0) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
        
    }
    
    
    public int viewservicelogs() {
        try {
            servicelogidlist.clear();
            vehicleidlist.clear();
            servicedescriptionlist.clear();
            mileagelist.clear();
            costlist.clear();
            servicedatelist.clear();
            servicestatuslist.clear();
            
            Connection conn;
            boolean success = false;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM servicelogs WHERE servicestatus = 'Pending'");
            ResultSet resultSet = pstmt.executeQuery();
            
            while (resultSet.next()) {
                    servicelogidlist.add(resultSet.getInt("servicelogid"));
                    vehicleidlist.add(resultSet.getInt("vehicleid"));
                    servicedescriptionlist.add(resultSet.getString("servicedescription"));
                    mileagelist.add(resultSet.getInt("mileage"));
                    costlist.add(resultSet.getDouble("cost"));
                    servicedatelist.add(resultSet.getString("servicedate"));
                    servicestatuslist.add(resultSet.getString("servicestatus"));
                    success = true;
                }
            
            pstmt.close();
            conn.close();
            
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int registrationChecker() {
        try {
            vehicleidlist.clear();
            ownerdriveridlist.clear();
            registrationnolist.clear();
            typelist.clear();
            makelist.clear();
            modellist.clear();
            seatingcapacitylist.clear();
            availabilitystatuslist.clear();
            
            Connection conn;
            boolean success = false;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM vehicle WHERE registrationno = ?");
            pstmt.setString(1,registrationno);
            ResultSet resultSet = pstmt.executeQuery();
            
            while (resultSet.next()) {
                    vehicleidlist.add(resultSet.getInt("vehicleid"));
                    ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                    registrationnolist.add(resultSet.getString("registrationno"));
                    typelist.add(resultSet.getString("type"));
                    makelist.add(resultSet.getString("make"));
                    modellist.add(resultSet.getString("model"));
                    seatingcapacitylist.add(resultSet.getInt("seatingcapacity"));
                    availabilitystatuslist.add(resultSet.getString("availabilitystatus"));
                    success = true;
                }
            
            pstmt.close();
            conn.close();
            
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int inputservicedetails() {
        try {
            Connection conn;
            boolean success = false;
            int count = 0, conflict = 0;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(servicelogid) + 1 AS newservicelogid FROM servicelogs");
            ResultSet rst = pstmt.executeQuery();
            
            while (rst.next()) {
                servicelogid = rst.getInt("newservicelogid");
            }
            
            pstmt = conn.prepareStatement("SELECT COUNT(*) AS count FROM rentalreservations WHERE (? BETWEEN rentalstartdate AND rentalenddate) AND vehicleid = ?");
            pstmt.setString(1,servicedate);
            pstmt.setInt(2, vehicleidlist.get(0));
            rst = pstmt.executeQuery();
            
            while (rst.next()) {
                count = rst.getInt("count");
            }
            
            pstmt = conn.prepareStatement("SELECT COUNT(*) AS conflict FROM servicelogs WHERE vehicleid = ? AND servicedate = ?");
            pstmt.setInt(1, vehicleidlist.get(0));
            pstmt.setString(2,servicedate);
            rst = pstmt.executeQuery();
            
            while (rst.next()) {
                conflict = rst.getInt("conflict");
            }
            
            if(count > 0){
                dateflagrental = 1;
            }
            
            if(conflict > 0){
                dateflagservice = 1;
            }
            
            if(count == 0 && conflict == 0){
                LocalDate today = LocalDate.now(); 
                String formattedDate = today.format(DateTimeFormatter.ISO_LOCAL_DATE);
                
                if(formattedDate.equals(servicedate)){
                    pstmt = conn.prepareStatement("DELETE FROM vehicleavailability WHERE vehicleid = ?");
                    pstmt.setInt(1,vehicleidlist.get(0));
                    pstmt.executeUpdate();
                
                    pstmt = conn.prepareStatement("UPDATE vehicle SET availabilitystatus = 'In Service' WHERE vehicleid = ?");
                    pstmt.setInt(1,vehicleidlist.get(0));
                    pstmt.executeUpdate();
                }
                
                servicestatus = "Pending";
                pstmt = conn.prepareStatement("INSERT INTO servicelogs VALUES (?,?,?,?,?,?,?)");
                pstmt.setInt(1,servicelogid);
                pstmt.setInt(2, vehicleidlist.get(0));
                pstmt.setString(3,servicedescription);
                pstmt.setInt(4, mileage);
                pstmt.setDouble(5,cost);
                pstmt.setString(6, servicedate);
                pstmt.setString(7, servicestatus);
                pstmt.executeUpdate();
                success = true;
            }
            
            pstmt.close();
            conn.close();
            
            if (success) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public static void main (String args[]) {
        
    }
}
