package VehicleRentalManagement;
import java.util.*;
import java.sql.*;

public class customer {
    
    // fields of customer
    public int customerid;
    public String firstname;
    public String lastname;
    public String email;
    public String phone_no;
    public String street;
    public String province;
    public String city_municipality;
    public int zipcode;
    public String country;

    // list of customer
    public ArrayList<Integer> customeridList =              new ArrayList<>();
    public ArrayList<String> firstnameList =                new ArrayList<>();
    public ArrayList<String> lastnameList =                 new ArrayList<>();
    public ArrayList<String> emailList =                    new ArrayList<>();
    public ArrayList<String> phone_noList =                 new ArrayList<>();
    public ArrayList<String> streetList =                   new ArrayList<>();
    public ArrayList<String> provinceList =                 new ArrayList<>();
    public ArrayList<String> city_municipalityList =        new ArrayList<>();
    public ArrayList<Integer> zipcodeList =                 new ArrayList<>();
    public ArrayList<String> countryList =                  new ArrayList<>();
    
    public String editfield;
    public String searchoptions;
    public String searchfield;
    public String listoptions;

    public customer() {}

    public int register_customer() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        try {
            int rowsAffected = 0;
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(customerid) + 1 AS newcustomerid FROM customer");
            ResultSet rst = pstmt.executeQuery();

            while (rst.next()) {
                customerid = rst.getInt("newcustomerid");
            }

            pstmt = conn.prepareStatement("INSERT INTO customer VALUES (?,?,?,?,?,?,?,?,?,?)");
            pstmt.setInt(1, customerid);
            pstmt.setString(2, firstname);
            pstmt.setString(3, lastname);
            pstmt.setString(4, email);
            pstmt.setString(5, phone_no);
            pstmt.setString(6, street);
            pstmt.setString(7, province);
            pstmt.setString(8, city_municipality);
            pstmt.setInt(9, zipcode);
            pstmt.setString(10, country);

            rowsAffected = pstmt.executeUpdate();

            pstmt.close();
            conn.close();

            if (rowsAffected > 0) {
                System.out.println("Successful");
                return 1;
            } else {
                System.out.println("Failed");
                return 0;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int getlatestcustomer() {
        try {
            boolean success = false;
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM customer WHERE customerid = (SELECT MAX(customerid) FROM customer)");
            ResultSet resultSet = pstmt.executeQuery();

            customeridList.clear();
            firstnameList.clear();
            lastnameList.clear();
            emailList.clear();
            phone_noList.clear();
            streetList.clear();
            provinceList.clear();
            city_municipalityList.clear();
            zipcodeList.clear();
            countryList.clear();

            while (resultSet.next()) {
                customeridList.add(resultSet.getInt("customerid"));
                firstnameList.add(resultSet.getString("firstname"));
                lastnameList.add(resultSet.getString("lastname"));
                emailList.add(resultSet.getString("email"));
                phone_noList.add(resultSet.getString("phone_no"));
                streetList.add(resultSet.getString("street"));
                provinceList.add(resultSet.getString("province"));
                city_municipalityList.add(resultSet.getString("city_municipality"));
                zipcodeList.add(resultSet.getInt("zipcode"));
                countryList.add(resultSet.getString("country"));
                success = true;
            }

            pstmt.close();
            conn.close();

            if (success) {
                System.out.println("Successful");
                return 1;
            } else {
                System.out.println("Failed");
                return 0;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int getcustomer() { 
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        try {
            boolean success = false;
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM customer WHERE customerid = ?");
            pstmt.setInt(1, customerid);
            ResultSet resultSet = pstmt.executeQuery();

            customeridList.clear();
            firstnameList.clear();
            lastnameList.clear();
            emailList.clear();
            phone_noList.clear();
            streetList.clear();
            provinceList.clear();
            city_municipalityList.clear();
            zipcodeList.clear();
            countryList.clear();

            while (resultSet.next()) {
                customeridList.add(resultSet.getInt("customerid"));
                firstnameList.add(resultSet.getString("firstname"));
                lastnameList.add(resultSet.getString("lastname"));
                emailList.add(resultSet.getString("email"));
                phone_noList.add(resultSet.getString("phone_no"));
                streetList.add(resultSet.getString("street"));
                provinceList.add(resultSet.getString("province"));
                city_municipalityList.add(resultSet.getString("city_municipality"));
                zipcodeList.add(resultSet.getInt("zipcode"));
                countryList.add(resultSet.getString("country"));
                success = true;
            }

            pstmt.close();
            conn.close();

            if (success) {
                System.out.println("Successful");
                return 1;
            } else {
                System.out.println("Failed");
                return 0;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int edit_customer() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            int rowsAffected = 0;
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement(
                "UPDATE customer SET " +
                "firstname = ?, " +
                "lastname = ?, " +
                "email = ?, " +
                "phone_no = ?, " +
                "street = ?, " +
                "province = ?, " +
                "city_municipality = ?, " +
                "zipcode = ?, " +
                "country = ? " +
                "WHERE customerid = ?");
            pstmt.setString(1, firstname);
            pstmt.setString(2, lastname);
            pstmt.setString(3, email);
            pstmt.setString(4, phone_no);
            pstmt.setString(5, street);
            pstmt.setString(6, province);
            pstmt.setString(7, city_municipality);
            pstmt.setInt(8, zipcode);
            pstmt.setString(9, "Philippines"); 
            pstmt.setInt(10, customerid);

            rowsAffected = pstmt.executeUpdate();

            pstmt.close();
            conn.close();

            if (rowsAffected > 0) {
                System.out.println("Successful");
                return 1;
            } else {
                System.out.println("Failed");
                return 0;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int transactionCustomerCheck() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(*) FROM rentalreservations WHERE customerid = ?");
            pstmt.setInt(1, customerid);
            ResultSet resultSet = pstmt.executeQuery();
            resultSet.next();
            int transactionCount = resultSet.getInt(1);
            pstmt.close();
            conn.close();

            if (transactionCount > 0) {
                System.out.println("Cannot delete customer with active transactions.");
                return 1;
            }
            
            return 0;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int delete_customer() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM customer WHERE customerid = ?");
            pstmt.setInt(1, customerid);
            int rowsAffected = pstmt.executeUpdate();
            pstmt.close();

            conn.close();
            pstmt.close();

            if (rowsAffected > 0) {
                System.out.println("Successful");
                return 1;
            } else {
                System.out.println("Failed");
                return 0;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int search_customer() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            PreparedStatement pstmt = null;
            ResultSet resultSet = null;
            boolean success = false;

            customeridList.clear();
            firstnameList.clear();
            lastnameList.clear();
            emailList.clear();
            phone_noList.clear();
            streetList.clear();
            provinceList.clear();
            city_municipalityList.clear();
            zipcodeList.clear();
            countryList.clear();

            StringBuilder query = new StringBuilder("SELECT * FROM customer WHERE 1=1");

            if (firstname != null && !firstname.isEmpty()) {
                query.append(" AND firstname LIKE ?");
            }
            if (lastname != null && !lastname.isEmpty()) {
                query.append(" AND lastname LIKE ?");
            }
            if (email != null && !email.isEmpty()) {
                query.append(" AND email LIKE ?");
            }
            if (phone_no != null && !phone_no.isEmpty()) {
                query.append(" AND phone_no LIKE ?");
            }

            query.append(" ORDER BY firstname");

            pstmt = conn.prepareStatement(query.toString());

            int parameterIndex = 1;
            if (firstname != null && !firstname.isEmpty()) {
                pstmt.setString(parameterIndex++, "%" + firstname + "%");
            }
            if (lastname != null && !lastname.isEmpty()) {
                pstmt.setString(parameterIndex++, "%" + lastname + "%");
            }
            if (email != null && !email.isEmpty()) {
                pstmt.setString(parameterIndex++, "%" + email + "%");
            }
            if (phone_no != null && !phone_no.isEmpty()) {
                pstmt.setString(parameterIndex, "%" + phone_no + "%");
            }

            resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                customeridList.add(resultSet.getInt("customerid"));
                firstnameList.add(resultSet.getString("firstname"));
                lastnameList.add(resultSet.getString("lastname"));
                emailList.add(resultSet.getString("email"));
                phone_noList.add(resultSet.getString("phone_no"));
                streetList.add(resultSet.getString("street"));
                provinceList.add(resultSet.getString("province"));
                city_municipalityList.add(resultSet.getString("city_municipality"));
                zipcodeList.add(resultSet.getInt("zipcode"));
                countryList.add(resultSet.getString("country"));
                success = true;
            }

            pstmt.close();
            conn.close();
            if (success) {
                System.out.println("Successful");
                return 1;
            } else {
                System.out.println("Failed");
                return 0;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int list_customer() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");

            customeridList.clear();
            firstnameList.clear();
            lastnameList.clear();
            emailList.clear();
            phone_noList.clear();
            streetList.clear();
            provinceList.clear();
            city_municipalityList.clear();
            zipcodeList.clear();
            countryList.clear();

            PreparedStatement pstmt = null;
            boolean success = false;

            String baseQuery = "SELECT * FROM customer ORDER BY ";
            String orderByClause = "";

            switch (listoptions) {
                case "listbyascid":
                    orderByClause = "customerid ASC";
                    break;

                case "listbydescid":
                    orderByClause = "customerid DESC";
                    break;

                case "listbyfirstname":
                    orderByClause = "firstname ASC";
                    break;

                case "listbylastname":
                    orderByClause = "lastname ASC";
                    break;

                case "listbyemail":
                    orderByClause = "email ASC";
                    break;

                case "listbyphoneno":
                    orderByClause = "phone_no ASC";
                    break;

                case "listbystreet":
                    orderByClause = "street ASC";
                    break;

                case "listbyprovince":
                    orderByClause = "province ASC";
                    break;

                case "listbycitymunicipality":
                    orderByClause = "city_municipality ASC";
                    break;

                case "listbyzipcode":
                    orderByClause = "zipcode ASC";
                    break;

                case "listbycountry":
                    orderByClause = "country ASC";
                    break;
            }

            String finalQuery = baseQuery + orderByClause;

            pstmt = conn.prepareStatement(finalQuery);
            ResultSet resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                customeridList.add(resultSet.getInt("customerid"));
                firstnameList.add(resultSet.getString("firstname"));
                lastnameList.add(resultSet.getString("lastname"));
                emailList.add(resultSet.getString("email"));
                phone_noList.add(resultSet.getString("phone_no"));
                streetList.add(resultSet.getString("street"));
                provinceList.add(resultSet.getString("province"));
                city_municipalityList.add(resultSet.getString("city_municipality"));
                zipcodeList.add(resultSet.getInt("zipcode"));
                countryList.add(resultSet.getString("country"));
                success = true;
            }

            if (pstmt != null) {
                pstmt.close();
            }

            conn.close();

            if (success) {
                System.out.println("Successful");
                return 1;
            } else {
                System.out.println("Failed");
                return 0;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
}
