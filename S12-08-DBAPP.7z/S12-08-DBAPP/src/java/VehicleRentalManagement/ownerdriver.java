package VehicleRentalManagement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ccslearner
 */
import java.util.*;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ownerdriver {
    
    public int    ownerdriverid;
    public String ownerfirstname;
    public String ownerlastname;
    public String driverfirstname;
    public String driverlastname;
    public String owner_email;
    public String driver_email;
    public String ownerphone_no;
    public String driverphone_no;
    public String driverlicenseno;
    public String newdataenter;
    public String editfield;
    public String searchfield;
    public String searchoptions;
    public String listoptions;
    
    public ArrayList<Integer> ownerdriveridlist = new ArrayList<>();
    public ArrayList<String> ownerfirstnamelist = new ArrayList<>();
    public ArrayList<String> ownerlastnamelist = new ArrayList<>();
    public ArrayList<String> driverfirstnamelist = new ArrayList<>();
    public ArrayList<String> driverlastnamelist = new ArrayList<>();
    public ArrayList<String> owner_emaillist = new ArrayList<>();
    public ArrayList<String> driver_emaillist = new ArrayList<>();
    public ArrayList<String> ownerphone_nolist = new ArrayList<>();
    public ArrayList<String> driverphone_nolist = new ArrayList<>();
    public ArrayList<String> driverlicensenolist = new ArrayList<>();
    
    public ownerdriver() {}
    
    public int register_ownerdriver() {
        
        try {
            Connection conn;
            String UPPERCASE_LETTER_PATTERN = "[A-Za-z]\\d{2}-\\d{2}-\\d{6}";
            int rowsAffected = 0;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(ownerdriverid) + 1 AS newownerdriverid FROM ownerdriver");
            ResultSet rst = pstmt.executeQuery();
            
            while (rst.next()) {
                ownerdriverid = rst.getInt("newownerdriverid");
            }
            
            pstmt = conn.prepareStatement("INSERT INTO ownerdriver VALUES (?,?,?,?,?,?,?,?,?,?)");
            pstmt.setInt(1,ownerdriverid);
            pstmt.setString(2, ownerfirstname);
            pstmt.setString(3,ownerlastname);
            pstmt.setString(4, driverfirstname);
            pstmt.setString(5,driverlastname);
            pstmt.setString(6, owner_email);
            pstmt.setString(7,driver_email);
            pstmt.setString(8,ownerphone_no);
            pstmt.setString(9,driverphone_no);
            Pattern pattern = Pattern.compile(UPPERCASE_LETTER_PATTERN);
            Matcher matcher = pattern.matcher(driverlicenseno);
            if(matcher.matches()){
                pstmt.setString(10,driverlicenseno);
            }
            rowsAffected = pstmt.executeUpdate();
            
            pstmt.close();
            conn.close();
            
            if (rowsAffected > 0) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
        
    }
    
    public int getlatestowner() {
         try {
            Connection conn;
            boolean success = false;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM ownerdriver WHERE ownerdriverid = (SELECT MAX(ownerdriverid) FROM ownerdriver)");
            ResultSet resultSet = pstmt.executeQuery();
            
            ownerdriveridlist.clear();
            ownerfirstnamelist.clear();
            ownerlastnamelist.clear();
            driverfirstnamelist.clear();
            driverlastnamelist.clear();
            owner_emaillist.clear();
            driver_emaillist.clear();
            ownerphone_nolist.clear();
            driverphone_nolist.clear();
            driverlicensenolist.clear();
            
            while (resultSet.next()) {
                    ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                    ownerfirstnamelist.add(resultSet.getString("ownerfirstname"));
                    ownerlastnamelist.add(resultSet.getString("ownerlastname"));
                    driverfirstnamelist.add(resultSet.getString("driverfirstname"));
                    driverlastnamelist.add(resultSet.getString("driverlastname"));
                    owner_emaillist.add(resultSet.getString("owner_email"));
                    driver_emaillist.add(resultSet.getString("driver_email"));
                    ownerphone_nolist.add(resultSet.getString("ownerphone_no"));
                    driverphone_nolist.add(resultSet.getString("driverphone_no"));
                    driverlicensenolist.add(resultSet.getString("driverlicenseno"));
                    success = true;
                }
            
            pstmt.close();
            conn.close();
            
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int getowner() {
         try {
            Connection conn;
            boolean success = false;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM ownerdriver WHERE ownerdriverid = ?");
            pstmt.setInt(1,ownerdriverid);
            ResultSet resultSet = pstmt.executeQuery();
            
            ownerdriveridlist.clear();
            ownerfirstnamelist.clear();
            ownerlastnamelist.clear();
            driverfirstnamelist.clear();
            driverlastnamelist.clear();
            owner_emaillist.clear();
            driver_emaillist.clear();
            ownerphone_nolist.clear();
            driverphone_nolist.clear();
            driverlicensenolist.clear();
            
            while (resultSet.next()) {
                    ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                    ownerfirstnamelist.add(resultSet.getString("ownerfirstname"));
                    ownerlastnamelist.add(resultSet.getString("ownerlastname"));
                    driverfirstnamelist.add(resultSet.getString("driverfirstname"));
                    driverlastnamelist.add(resultSet.getString("driverlastname"));
                    owner_emaillist.add(resultSet.getString("owner_email"));
                    driver_emaillist.add(resultSet.getString("driver_email"));
                    ownerphone_nolist.add(resultSet.getString("ownerphone_no"));
                    driverphone_nolist.add(resultSet.getString("driverphone_no"));
                    driverlicensenolist.add(resultSet.getString("driverlicenseno"));
                    success = true;
                }
            
            pstmt.close();
            conn.close();
            
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int delete_ownerdriver() {
        
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM ownerdriver WHERE ownerdriverid = ?");
            pstmt.setInt(1,ownerdriverid);
            int rowsAffected = pstmt.executeUpdate();
            
            pstmt.close();
            conn.close();
            
            if (rowsAffected > 0) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
        
        public int edit_ownerdriver() {
        
        try {
            Connection conn;
            String UPPERCASE_LETTER_PATTERN = "[A-Za-z]\\d{2}-\\d{2}-\\d{6}";
            int rowsAffected = 0;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement(
                "UPDATE ownerdriver SET " +
                "ownerfirstname = ?, " +
                "ownerlastname = ?, " +
                "driverfirstname = ?, " +
                "driverlastname = ?, " +
                "owner_email = ?, " +
                "driver_email = ?, " +
                "ownerphone_no = ?, " +
                "driverphone_no = ?, " +
                "driverlicenseno = ? " +
                "WHERE ownerdriverid = ?");
            pstmt.setString(1, ownerfirstname);
            pstmt.setString(2,ownerlastname);
            pstmt.setString(3, driverfirstname);
            pstmt.setString(4,driverlastname);
            pstmt.setString(5, owner_email);
            pstmt.setString(6,driver_email);
            pstmt.setString(7,ownerphone_no);
            pstmt.setString(8,driverphone_no);
            Pattern pattern = Pattern.compile(UPPERCASE_LETTER_PATTERN);
            Matcher matcher = pattern.matcher(driverlicenseno);
            if(matcher.matches()){
                pstmt.setString(9,driverlicenseno);
            }
            pstmt.setInt(10,ownerdriverid);
            rowsAffected = pstmt.executeUpdate();
            
            pstmt.close();
            conn.close();
            
            if (rowsAffected > 0) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
        
    }
        
    public int search_ownerdriver() {
        
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            PreparedStatement pstmt = null;
            ResultSet resultSet = null;
            boolean success = false;
            
            ownerdriveridlist.clear();
            ownerfirstnamelist.clear();
            ownerlastnamelist.clear();
            driverfirstnamelist.clear();
            driverlastnamelist.clear();
            owner_emaillist.clear();
            driver_emaillist.clear();
            ownerphone_nolist.clear();
            driverphone_nolist.clear();
            driverlicensenolist.clear();
            
            StringBuilder query = new StringBuilder("SELECT * FROM ownerdriver WHERE 1=1");

            if (ownerfirstname != null && !ownerfirstname.isEmpty() && driverfirstname != null && !driverfirstname.isEmpty()) {
                query.append(" AND (ownerfirstname LIKE ? OR driverfirstname LIKE ?)");
            }
            if (ownerlastname != null && !ownerlastname.isEmpty() && driverlastname != null && !driverlastname.isEmpty()) {
                query.append(" AND (ownerlastname LIKE ? OR driverlastname LIKE ?)");
            }
            if (owner_email != null && !owner_email.isEmpty() && driver_email != null && !driver_email.isEmpty()) {
                query.append(" AND (owner_email LIKE ? OR driver_email LIKE ?)");
            }
            if (ownerphone_no != null && !ownerphone_no.isEmpty() && driverphone_no != null && !driverphone_no.isEmpty()) {
                query.append(" AND (ownerphone_no LIKE ? OR driverphone_no LIKE ?)");
            }
            if (driverlicenseno != null && !driverlicenseno.isEmpty()) {
                query.append(" AND (driverlicenseno LIKE ?)");
            }
            
            query.append(" ORDER BY ownerfirstname");
            
            pstmt = conn.prepareStatement(query.toString());

            int parameterIndex = 1;
            if (ownerfirstname != null && !ownerfirstname.isEmpty() && driverfirstname != null && !driverfirstname.isEmpty()) {
                pstmt.setString(parameterIndex++, "%" + ownerfirstname + "%");
                pstmt.setString(parameterIndex++, "%" + driverfirstname + "%");
            }
            if (ownerlastname != null && !ownerlastname.isEmpty() && driverlastname != null && !driverlastname.isEmpty()) {
                pstmt.setString(parameterIndex++, "%" + ownerlastname + "%");
                pstmt.setString(parameterIndex++, "%" + driverlastname + "%");
            }
            if (owner_email != null && !owner_email.isEmpty() && driver_email != null && !driver_email.isEmpty()) {
                pstmt.setString(parameterIndex++, "%" + owner_email + "%");
                pstmt.setString(parameterIndex++, "%" + driver_email + "%");
            }
            if (ownerphone_no != null && !ownerphone_no.isEmpty() && driverphone_no != null && !driverphone_no.isEmpty()) {
                pstmt.setString(parameterIndex++, "%" + ownerphone_no + "%");
                pstmt.setString(parameterIndex++, "%" + driverphone_no + "%");
            }
            if (driverlicenseno != null && !driverlicenseno.isEmpty()) {
                pstmt.setString(parameterIndex, "%" + driverlicenseno + "%");
            }

            resultSet = pstmt.executeQuery();
                
                while (resultSet.next()) {
                    ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                    ownerfirstnamelist.add(resultSet.getString("ownerfirstname"));
                    ownerlastnamelist.add(resultSet.getString("ownerlastname"));
                    driverfirstnamelist.add(resultSet.getString("driverfirstname"));
                    driverlastnamelist.add(resultSet.getString("driverlastname"));
                    owner_emaillist.add(resultSet.getString("owner_email"));
                    driver_emaillist.add(resultSet.getString("driver_email"));
                    ownerphone_nolist.add(resultSet.getString("ownerphone_no"));
                    driverphone_nolist.add(resultSet.getString("driverphone_no"));
                    driverlicensenolist.add(resultSet.getString("driverlicenseno"));
                    success = true;
                }
            
            pstmt.close();
            conn.close();
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int view_ownerdriver() {
        
        try {
            Connection conn;
            boolean success = false;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            ownerdriveridlist.clear();
            ownerfirstnamelist.clear();
            ownerlastnamelist.clear();
            driverfirstnamelist.clear();
            driverlastnamelist.clear();
            owner_emaillist.clear();
            driver_emaillist.clear();
            ownerphone_nolist.clear();
            driverphone_nolist.clear();
            driverlicensenolist.clear();
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM ownerdriver WHERE ownerdriverid = ?;");
            pstmt.setInt(1, ownerdriverid);
            ResultSet resultSet = pstmt.executeQuery();
            
            while (resultSet.next()) {
                ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                ownerfirstnamelist.add(resultSet.getString("ownerfirstname"));
                ownerlastnamelist.add(resultSet.getString("ownerlastname"));
                driverfirstnamelist.add(resultSet.getString("driverfirstname"));
                driverlastnamelist.add(resultSet.getString("driverlastname"));
                owner_emaillist.add(resultSet.getString("owner_email"));
                driver_emaillist.add(resultSet.getString("driver_email"));
                ownerphone_nolist.add(resultSet.getString("ownerphone_no"));
                driverphone_nolist.add(resultSet.getString("driverphone_no"));
                driverlicensenolist.add(resultSet.getString("driverlicenseno"));
                success = true;
            }
            
            pstmt.close();
            conn.close();
            
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int list_ownerdriver() {
        
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            PreparedStatement pstmt = null;
            ResultSet resultSet = null;
            boolean success = false;
            
            ownerdriveridlist.clear();
            ownerfirstnamelist.clear();
            ownerlastnamelist.clear();
            driverfirstnamelist.clear();
            driverlastnamelist.clear();
            owner_emaillist.clear();
            driver_emaillist.clear();
            ownerphone_nolist.clear();
            driverphone_nolist.clear();
            driverlicensenolist.clear();
            
            switch (listoptions) {
                case "listbyascid":
                pstmt = conn.prepareStatement("SELECT * FROM ownerdriver ORDER BY ownerdriverid ASC;");
                resultSet = pstmt.executeQuery();
                
                while (resultSet.next()) {
                    ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                    ownerfirstnamelist.add(resultSet.getString("ownerfirstname"));
                    ownerlastnamelist.add(resultSet.getString("ownerlastname"));
                    driverfirstnamelist.add(resultSet.getString("driverfirstname"));
                    driverlastnamelist.add(resultSet.getString("driverlastname"));
                    owner_emaillist.add(resultSet.getString("owner_email"));
                    driver_emaillist.add(resultSet.getString("driver_email"));
                    ownerphone_nolist.add(resultSet.getString("ownerphone_no"));
                    driverphone_nolist.add(resultSet.getString("driverphone_no"));
                    driverlicensenolist.add(resultSet.getString("driverlicenseno"));
                    success = true;
                }
                break;
                
                case "listbydescid":
                pstmt = conn.prepareStatement("SELECT * FROM ownerdriver ORDER BY ownerdriverid DESC;");
                resultSet = pstmt.executeQuery();
                
                while (resultSet.next()) {
                    ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                    ownerfirstnamelist.add(resultSet.getString("ownerfirstname"));
                    ownerlastnamelist.add(resultSet.getString("ownerlastname"));
                    driverfirstnamelist.add(resultSet.getString("driverfirstname"));
                    driverlastnamelist.add(resultSet.getString("driverlastname"));
                    owner_emaillist.add(resultSet.getString("owner_email"));
                    driver_emaillist.add(resultSet.getString("driver_email"));
                    ownerphone_nolist.add(resultSet.getString("ownerphone_no"));
                    driverphone_nolist.add(resultSet.getString("driverphone_no"));
                    driverlicensenolist.add(resultSet.getString("driverlicenseno"));
                    success = true;
                }
                break;
                
                case "listbyownerfirstname":
                pstmt = conn.prepareStatement("SELECT * FROM ownerdriver ORDER BY ownerfirstname ASC;");
                resultSet = pstmt.executeQuery();
                
                while (resultSet.next()) {
                    ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                    ownerfirstnamelist.add(resultSet.getString("ownerfirstname"));
                    ownerlastnamelist.add(resultSet.getString("ownerlastname"));
                    driverfirstnamelist.add(resultSet.getString("driverfirstname"));
                    driverlastnamelist.add(resultSet.getString("driverlastname"));
                    owner_emaillist.add(resultSet.getString("owner_email"));
                    driver_emaillist.add(resultSet.getString("driver_email"));
                    ownerphone_nolist.add(resultSet.getString("ownerphone_no"));
                    driverphone_nolist.add(resultSet.getString("driverphone_no"));
                    driverlicensenolist.add(resultSet.getString("driverlicenseno"));
                    success = true;
                }
                break;
                
                case "listbyownerlastname":
                pstmt = conn.prepareStatement("SELECT * FROM ownerdriver ORDER BY ownerlastname ASC;");
                resultSet = pstmt.executeQuery();
                
                while (resultSet.next()) {
                    ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                    ownerfirstnamelist.add(resultSet.getString("ownerfirstname"));
                    ownerlastnamelist.add(resultSet.getString("ownerlastname"));
                    driverfirstnamelist.add(resultSet.getString("driverfirstname"));
                    driverlastnamelist.add(resultSet.getString("driverlastname"));
                    owner_emaillist.add(resultSet.getString("owner_email"));
                    driver_emaillist.add(resultSet.getString("driver_email"));
                    ownerphone_nolist.add(resultSet.getString("ownerphone_no"));
                    driverphone_nolist.add(resultSet.getString("driverphone_no"));
                    driverlicensenolist.add(resultSet.getString("driverlicenseno"));
                    success = true;
                }
                break;
                
                case "listbydriverfirstname":
                pstmt = conn.prepareStatement("SELECT * FROM ownerdriver ORDER BY driverfirstname ASC;");
                resultSet = pstmt.executeQuery();
                
                while (resultSet.next()) {
                    ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                    ownerfirstnamelist.add(resultSet.getString("ownerfirstname"));
                    ownerlastnamelist.add(resultSet.getString("ownerlastname"));
                    driverfirstnamelist.add(resultSet.getString("driverfirstname"));
                    driverlastnamelist.add(resultSet.getString("driverlastname"));
                    owner_emaillist.add(resultSet.getString("owner_email"));
                    driver_emaillist.add(resultSet.getString("driver_email"));
                    ownerphone_nolist.add(resultSet.getString("ownerphone_no"));
                    driverphone_nolist.add(resultSet.getString("driverphone_no"));
                    driverlicensenolist.add(resultSet.getString("driverlicenseno"));
                    success = true;
                }
                break;
                
                case "listbydriverlastname":
                pstmt = conn.prepareStatement("SELECT * FROM ownerdriver ORDER BY driverlastname ASC;");
                resultSet = pstmt.executeQuery();
                
                while (resultSet.next()) {
                    ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                    ownerfirstnamelist.add(resultSet.getString("ownerfirstname"));
                    ownerlastnamelist.add(resultSet.getString("ownerlastname"));
                    driverfirstnamelist.add(resultSet.getString("driverfirstname"));
                    driverlastnamelist.add(resultSet.getString("driverlastname"));
                    owner_emaillist.add(resultSet.getString("owner_email"));
                    driver_emaillist.add(resultSet.getString("driver_email"));
                    ownerphone_nolist.add(resultSet.getString("ownerphone_no"));
                    driverphone_nolist.add(resultSet.getString("driverphone_no"));
                    driverlicensenolist.add(resultSet.getString("driverlicenseno"));
                    success = true;
                }
                break;
                
                case "listbydriverlicenseno":
                pstmt = conn.prepareStatement("SELECT * FROM ownerdriver ORDER BY driverlicenseno ASC;");
                resultSet = pstmt.executeQuery();
                
                while (resultSet.next()) {
                    ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                    ownerfirstnamelist.add(resultSet.getString("ownerfirstname"));
                    ownerlastnamelist.add(resultSet.getString("ownerlastname"));
                    driverfirstnamelist.add(resultSet.getString("driverfirstname"));
                    driverlastnamelist.add(resultSet.getString("driverlastname"));
                    owner_emaillist.add(resultSet.getString("owner_email"));
                    driver_emaillist.add(resultSet.getString("driver_email"));
                    ownerphone_nolist.add(resultSet.getString("ownerphone_no"));
                    driverphone_nolist.add(resultSet.getString("driverphone_no"));
                    driverlicensenolist.add(resultSet.getString("driverlicenseno"));
                    success = true;
                }
                break;
            }
            
            pstmt.close();
            conn.close();
            
            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public static void main (String args[]) {
        
    }
}
