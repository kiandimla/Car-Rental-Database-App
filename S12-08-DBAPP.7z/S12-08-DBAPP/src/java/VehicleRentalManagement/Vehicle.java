package VehicleRentalManagement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ccslearner
 */
import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.Calendar;
import java.util.concurrent.ThreadLocalRandom;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;



public class Vehicle {
    
    //fields of assets
    public int ownerdriverid;
    public int vehicleid;
    public String registrationno;
    public String type;
    public String make;
    public String model;
    public int seatingcapacity;
    public Double rentalrateperday;
    public String availabilitystatus;
    public String searchoptions;
    public String searchfield;
    public Double locx;
    public Double locy;
    public String firstname;
    public String lastname;
    public String email;
    public String phone_no;
    public String street;
    public String province;
    public String city_municipality;
    public int zipcode;
    public String country;
    public int customerid;
    
    public ArrayList<Integer> ownerdriveridlist = new ArrayList<>();
    public ArrayList<Integer> vehicleidlist = new ArrayList<>();
    public ArrayList<String> registrationnolist = new ArrayList<>();
    public ArrayList<String> typelist = new ArrayList<>();
    public ArrayList<String> makelist = new ArrayList<>();
    public ArrayList<String> modellist = new ArrayList<>();
    public ArrayList<Integer> seatingcapacitylist = new ArrayList<>();
    public ArrayList<Double> rentalrateperdaylist = new ArrayList<>();
    public ArrayList<String> availabilitystatuslist = new ArrayList<>();
    
    public Vehicle(){
    }
    
    public List<String> getDistinctVehicleTypes() throws SQLException {
        List<String> types = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678")) {
            PreparedStatement pst = conn.prepareStatement("SELECT DISTINCT type FROM vehicle");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                types.add(rs.getString("type"));
            }
        }
        return types;
    }
    
    public List<String> getDistinctMakes() throws SQLException {
        List<String> makes = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678")) {
            PreparedStatement pst = conn.prepareStatement("SELECT DISTINCT make FROM vehicle");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                makes.add(rs.getString("make"));
            }
        }
        return makes;
    }
    
    public List<String> getDistinctModels() throws SQLException {
        List<String> models = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678")) {
            PreparedStatement pst = conn.prepareStatement("SELECT DISTINCT model FROM vehicle");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                models.add(rs.getString("model"));
            }
        }
        return models;
    }
    
    public List<Integer> getDistinctSeatingCapacitiesforsearch() throws SQLException {
        List<Integer> capacities = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678")) {
            PreparedStatement pst = conn.prepareStatement("SELECT DISTINCT seatingcapacity FROM vehicle");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                capacities.add(rs.getInt("seatingcapacity"));
            }
        }
        return capacities;
    }
    
    public List<String> getDistinctAvailabilityStatuses() throws SQLException {
        List<String> statuses = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678")) {
            PreparedStatement pst = conn.prepareStatement("SELECT DISTINCT availabilitystatus FROM vehicle");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                statuses.add(rs.getString("availabilitystatus"));
            }
        }
        return statuses;
    }
    
    public int countServiceOccurrences(int vehicleId) {
        int occurrences = 0;
        
        // SQL query to count occurrences of vehicleId in servicelogs
        String query = "SELECT COUNT(*) AS service_occurrences FROM servicelogs WHERE vehicleid = ?";

        // AutoCloseable resources in the try-with-resources statement will be closed at the end
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
             PreparedStatement pstmt = conn.prepareStatement(query)) {
             
            pstmt.setInt(1, vehicleId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    occurrences = rs.getInt("service_occurrences");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return occurrences;
    }
      
   public int checkDateAffectingServiceLogs(Date specificDate, int vehicleId) {
        if (specificDate == null) {
            return 0;
        }
        int count = 0;
        // Connection string should include your database name and credentials
        String url = "jdbc:mysql://localhost:3306/VRM?user=root&password=12345678";
        // SQL query to check if a specific date falls within any service log durations
        // for a specific vehicle and the service status is 'Pending'
        String query = "SELECT COUNT(*) AS affected_service_logs " +
                       "FROM servicelogs " +
                       "WHERE ? BETWEEN servicedate AND servicedate " +
                       "AND vehicleid = ? " +
                       "AND servicestatus = 'Pending'";

        // Try-with-resources to ensure that resources are closed after the operation
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            // Set the specific date and vehicle ID into the query
            pstmt.setDate(1, specificDate);
            pstmt.setInt(2, vehicleId); // Set the vehicle ID
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    count = rs.getInt("affected_service_logs");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }
    
    public int register_vehicle(){
        try{
            //codes to interact with db
            //1. Connect to DB
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Success");
            
            //2. Prepare SQL Statement
            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(vehicleid) + 1 AS newID FROM vehicle");
            ResultSet rst = pstmt.executeQuery();
            while (rst.next()){
                vehicleid = rst.getInt("newID");
            }
            
            //2.2 Save
            pstmt = conn.prepareStatement("INSERT INTO vehicle VALUE (?,?,?,?,?,?,?,?,?)");
            pstmt.setInt(1,vehicleid);
            pstmt.setInt(2,ownerdriverid);
            pstmt.setString(3, registrationno);
            pstmt.setString(4,type);
            pstmt.setString(5, make);
            pstmt.setString(6,model);
            pstmt.setInt(7,seatingcapacity);
            pstmt.setDouble(8,rentalrateperday);
            pstmt.setString(9,"Available");
            pstmt.executeUpdate();
                
            pstmt.close();
            conn.close();
            return 1;
        } catch (Exception e){
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public static boolean checkOwnerDriverExists(String ownerDriverId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean exists = false;

        try {
            // Establish a database connection (update connection URL, username, and password)
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");

            // Define the SQL query to check if the owner driver ID exists
            String sql = "SELECT COUNT(*) FROM ownerdriver WHERE ownerdriverid = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, ownerDriverId);

            // Execute the query
            rs = pstmt.executeQuery();

            // Check if any records were found
            if (rs.next()) {
                int count = rs.getInt(1);
                exists = (count > 0); // Set to true if owner driver ID exists
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return exists;
    }
    
    public boolean checkVehicleInReservation(int vehicleId) {
        String sql = "SELECT COUNT(*) FROM rentalreservations WHERE vehicleid = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, vehicleId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
        return false;
    }
    
    public boolean checkVehicleInService(int vehicleId) {
        String sql = "SELECT COUNT(*) FROM servicelogs WHERE vehicleid = ? AND servicestatus = 'Pending'";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, vehicleId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
        return false;
    }
       
    public int getLastInsertedVehicleId() throws SQLException {

    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;

    try {
      conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");

      String sql = "SELECT MAX(vehicleid) FROM vehicle";
      stmt = conn.createStatement();
      rs = stmt.executeQuery(sql);

      if (rs.next()) {
        return rs.getInt(1);
      }
    } finally {
      if (rs != null) {
        rs.close();
      }
      if (stmt != null) {
        stmt.close();
      }
      if (conn != null) {
        conn.close();
      }
    }

    return -1;
  }
    
    public int delete_vehicle(int vehicleid) {
        int rowsAffected = 0;
        String dbUrl = "jdbc:mysql://localhost:3306/VRM";
        String dbUser = "root";
        String dbPass = "12345678";
        
        // SQL statement to delete a vehicle record
        String deleteVehicleSql = "DELETE FROM vehicle WHERE vehicleid = ?";

        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
             PreparedStatement pstmt = conn.prepareStatement(deleteVehicleSql)) {

            // Set the vehicleid parameter in the SQL query
            pstmt.setInt(1, vehicleid);

            // Execute the delete operation
            rowsAffected = pstmt.executeUpdate();
            
            // Check if the delete was successful
            if (rowsAffected > 0) {
                System.out.println("Vehicle deleted successfully.");
            } else {
                System.out.println("No vehicle records found to delete or vehicle is already deleted.");
            }

        } catch (SQLException e) {
            System.out.println("SQL exception occurred during vehicle deletion.");
            e.printStackTrace();
        }

        // Return the number of rows affected
        return rowsAffected;
    }
    
    public int delete_vehicleAvailability(int vehicleid) {
        // Initialize the result status
        int rowsAffected = 0;
        
        // Database URL, username, and password should be securely stored and retrieved, not hardcoded
        String dbUrl = "jdbc:mysql://localhost:3306/VRM";
        String dbUser = "root";
        String dbPass = "12345678";
        
        // SQL statement to delete availability records
        String deleteAvailabilitySql = "DELETE FROM vehicleavailability WHERE vehicleid = ?";

        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
             PreparedStatement pstmt = conn.prepareStatement(deleteAvailabilitySql)) {

            // Set the vehicleid parameter in the SQL query
            pstmt.setInt(1, vehicleid);

            // Execute the delete operation
            rowsAffected = pstmt.executeUpdate();
            
            // Check if the delete was successful
            if (rowsAffected > 0) {
                System.out.println("Vehicle availability deleted successfully.");
            } else {
                System.out.println("No vehicle availability records found to delete.");
            }

        } catch (SQLException e) {
            System.out.println("SQL exception occurred during vehicle availability deletion.");
            e.printStackTrace();
        }

        // Return the number of rows affected
        return rowsAffected;
    }
    
    public int edit_vehicle(String editField, String editValue) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt;
            
            switch (editField) {
                case "ownerdriverid":
                    pstmt = conn.prepareStatement("UPDATE vehicle SET ownerdriverid = ? WHERE vehicleid = ?");
                    pstmt.setInt(1, Integer.parseInt(editValue));
                    pstmt.setInt(2, vehicleid);
                    break;
                case "registrationno":
                    pstmt = conn.prepareStatement("UPDATE vehicle SET registrationno = ? WHERE vehicleid = ?");
                    pstmt.setString(1, editValue);
                    pstmt.setInt(2, vehicleid);
                    break;
                case "type":
                    pstmt = conn.prepareStatement("UPDATE vehicle SET type = ? WHERE vehicleid = ?");
                    pstmt.setString(1, editValue);
                    pstmt.setInt(2, vehicleid);
                    break;
                case "make":
                    pstmt = conn.prepareStatement("UPDATE vehicle SET make = ? WHERE vehicleid = ?");
                    pstmt.setString(1, editValue);
                    pstmt.setInt(2, vehicleid);
                    break;
                case "model":
                    pstmt = conn.prepareStatement("UPDATE vehicle SET model = ? WHERE vehicleid = ?");
                    pstmt.setString(1, editValue);
                    pstmt.setInt(2, vehicleid);
                    break;
                case "seatingcapacity":
                    pstmt = conn.prepareStatement("UPDATE vehicle SET seatingcapacity = ? WHERE vehicleid = ?");
                    pstmt.setInt(1, Integer.parseInt(editValue));
                    pstmt.setInt(2, vehicleid);
                    break;
                case "rentalrateperday":
                    pstmt = conn.prepareStatement("UPDATE vehicle SET rentalrateperday = ? WHERE vehicleid = ?");
                    pstmt.setDouble(1, Double.parseDouble(editValue));
                    pstmt.setInt(2, vehicleid);
                    break;
                case "availabilitystatus":
                    pstmt = conn.prepareStatement("UPDATE vehicle SET availabilitystatus = ? WHERE vehicleid = ?");
                    pstmt.setString(1, editValue);
                    pstmt.setInt(2, vehicleid);
                    break;
                default:
                    System.out.println("Invalid field to edit");
                    return 0;
            }
            
            int rowsAffected = pstmt.executeUpdate();
            
            pstmt.close();
            conn.close();
            
            if (rowsAffected > 0) {
                System.out.println("Successful");
                return 1;
            } else {
                System.out.println("Failed");
                return 0;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public boolean ownerDriverIdExists(int ownerDriverId) {
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    boolean exists = false;

    try {
        // Assume you have a method getConnection() that sets up your database connection
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
        
        String query = "SELECT COUNT(*) FROM ownerdriver WHERE ownerdriverid = ?";
        pstmt = conn.prepareStatement(query);
        pstmt.setInt(1, ownerDriverId);

        rs = pstmt.executeQuery();
        
        if (rs.next()) {
            // If the count is greater than 0, the ID exists
            exists = rs.getInt(1) > 0;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle exceptions
    } finally {
        // Close all resources
        try {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    return exists;
}
    
    public static Vehicle getVehicleById(int vehicleId, Connection conn) throws SQLException {
        Vehicle vehicle = null;
        String query = "SELECT * FROM vehicle WHERE vehicleid = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, vehicleId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                vehicle = new Vehicle();
                vehicle.setVehicleid(rs.getInt("vehicleid"));
                vehicle.setOwnerdriverid(rs.getInt("ownerdriverid"));
                vehicle.setRegistrationno(rs.getString("registrationno"));
                vehicle.setType(rs.getString("type"));
                vehicle.setMake(rs.getString("make"));
                vehicle.setModel(rs.getString("model"));
                vehicle.setSeatingcapacity(rs.getInt("seatingcapacity"));
                vehicle.setRentalrateperday(rs.getDouble("rentalrateperday"));
                vehicle.setAvailabilitystatus(rs.getString("availabilitystatus"));
            }
        }
        return vehicle;
    }

    public Vehicle searchVehicleByID(int vehicleID) {
    // Initialize variables
    Vehicle vehicle = null;
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        // Establish a database connection
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");

        // Prepare a SQL query to retrieve vehicle information by ID
        String sql = "SELECT * FROM vehicle WHERE vehicleid = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, vehicleID);

        // Execute the query
        rs = pstmt.executeQuery();

        // Check if a matching vehicle record was found
        if (rs.next()) {
            // Create a Vehicle object and populate it with the retrieved data
            vehicle = new Vehicle();
            vehicle.setVehicleid(rs.getInt("vehicleid"));
            vehicle.setOwnerdriverid(rs.getInt("ownerdriverid"));
            vehicle.setRegistrationno(rs.getString("registrationno"));
            vehicle.setType(rs.getString("type"));
            vehicle.setMake(rs.getString("make"));
            vehicle.setModel(rs.getString("model"));
            vehicle.setSeatingcapacity(rs.getInt("seatingcapacity"));
            vehicle.setRentalrateperday(rs.getDouble("rentalrateperday"));
            vehicle.setAvailabilitystatus(rs.getString("availabilitystatus"));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Close database resources
        try {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return vehicle;
}

    public List<Vehicle> searchVehiclesByAttributes(String searchTerm) {
        List<Vehicle> vehicles = new ArrayList<>();

        // Parse the search term and construct the SQL query
        String[] searchTerms = searchTerm.split("&");
        String sql = "SELECT * FROM vehicle WHERE 1=1";
        List<Object> params = new ArrayList<>();

        for (String term : searchTerms) {
            String[] keyValue = term.split("=");
            if (keyValue.length == 2) {
                String key = keyValue[0];
                String value = keyValue[1];
                
                try {
                value = URLDecoder.decode(keyValue[1], StandardCharsets.UTF_8.name());
                } catch (Exception e) { // Catch any exception, although it's unlikely to occur here
                e.printStackTrace();
                continue; // Skip to the next iteration in case of an exception
                }
                
                // Add conditions based on the key and value
                if ("vehicleType".equals(key)) {
                    sql += " AND type = ?";
                    params.add(value);
                } else if ("make".equals(key)) {
                    sql += " AND make = ?";
                    params.add(value);
                } else if ("model".equals(key)) {
                    sql += " AND model = ?";
                    params.add(value);
                } else if ("seatingCapacity".equals(key)) {
                    sql += " AND seatingcapacity = ?";
                    params.add(Integer.parseInt(value));
                } else if ("rentalRate".equals(key)) {
                    sql += " AND rentalrateperday <= ?";
                    params.add(new BigDecimal(value));
                } else if ("availabilityStatus".equals(key)) {
                    sql += " AND availabilitystatus = ?";
                    params.add(value);
                } else if ("ownerId".equals(key)) {
                    sql += " AND ownerdriverid = ?";
                    params.add(Integer.parseInt(value));
                }
            }
        }

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            
            PreparedStatement stmt = conn.prepareStatement(sql);

            // Set parameter values based on the search criteria
            int paramIndex = 1;
            for (Object param : params) {
                if (param instanceof String) {
                    stmt.setString(paramIndex, (String) param);
                } else if (param instanceof Integer) {
                    stmt.setInt(paramIndex, (Integer) param);
                } else if (param instanceof BigDecimal) {
                    stmt.setBigDecimal(paramIndex, (BigDecimal) param);
                }
                paramIndex++;
            }

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Vehicle vehicle = new Vehicle();
                // Set the vehicle properties based on the result set
                vehicle.setVehicleid(rs.getInt("vehicleid"));
                vehicle.setOwnerdriverid(rs.getInt("ownerdriverid"));
                vehicle.setRegistrationno(rs.getString("registrationno"));
                vehicle.setType(rs.getString("type"));
                vehicle.setMake(rs.getString("make"));
                vehicle.setModel(rs.getString("model"));
                vehicle.setSeatingcapacity(rs.getInt("seatingcapacity"));
                vehicle.setRentalrateperday(rs.getDouble("rentalrateperday"));
                vehicle.setAvailabilitystatus(rs.getString("availabilitystatus"));
                
                vehicles.add(vehicle);
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return vehicles;
    }
       
    public int view_vehicle() {

        try {
            Connection conn;
            boolean success = false;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");

            ownerdriveridlist.clear();
            vehicleidlist.clear();
            registrationnolist.clear();
            typelist.clear();
            makelist.clear();
            modellist.clear();
            seatingcapacitylist.clear();
            rentalrateperdaylist.clear();
            availabilitystatuslist.clear();;

            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM vehicle;");
            ResultSet resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                vehicleidlist.add(resultSet.getInt("vehicleid"));
                ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
                registrationnolist.add(resultSet.getString("registrationno"));
                typelist.add(resultSet.getString("type"));
                makelist.add(resultSet.getString("make"));
                modellist.add(resultSet.getString("model"));
                seatingcapacitylist.add(resultSet.getInt("seatingcapacity"));
                rentalrateperdaylist.add(resultSet.getDouble("rentalrateperday"));
                availabilitystatuslist.add(resultSet.getString("availabilitystatus"));
                success = true;
            }

            pstmt.close();
            conn.close();

            if (success == true) {
                System.out.println("Successful");
                return 1;
            }
            else {
                System.out.println("Failed");
                return 0;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int list_vehicle(String sortCriteria) {
    try {
        Connection conn;
        boolean success = false;
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
        System.out.println("Connection Successful");

        ownerdriveridlist.clear();
        vehicleidlist.clear();
        registrationnolist.clear();
        typelist.clear();
        makelist.clear();
        modellist.clear();
        seatingcapacitylist.clear();
        rentalrateperdaylist.clear();
        availabilitystatuslist.clear();

        String query = "SELECT * FROM vehicle";

        switch (sortCriteria) {
            case "ascending":
                query += " ORDER BY vehicleid ASC";
                break;
            case "descending":
                query += " ORDER BY vehicleid DESC";
                break;
            case "highestRate":
                query += " ORDER BY rentalrateperday DESC";
                break;
            case "lowestRate":
                query += " ORDER BY rentalrateperday ASC";
                break;
            case "makeAlphabetical":
                query += " ORDER BY make ASC";
                break;
            case "modelAlphabetical":
                query += " ORDER BY model ASC";
                break;
            default:
                // No sorting specified, use the default query
                break;
        }

        PreparedStatement pstmt = conn.prepareStatement(query);
        ResultSet resultSet = pstmt.executeQuery();

        while (resultSet.next()) {
            vehicleidlist.add(resultSet.getInt("vehicleid"));
            ownerdriveridlist.add(resultSet.getInt("ownerdriverid"));
            registrationnolist.add(resultSet.getString("registrationno"));
            typelist.add(resultSet.getString("type"));
            makelist.add(resultSet.getString("make"));
            modellist.add(resultSet.getString("model"));
            seatingcapacitylist.add(resultSet.getInt("seatingcapacity"));
            rentalrateperdaylist.add(resultSet.getDouble("rentalrateperday"));
            availabilitystatuslist.add(resultSet.getString("availabilitystatus"));
            success = true;
        }

        pstmt.close();
        conn.close();

        if (success) {
            System.out.println("Successful");
            return 1;
        } else {
            System.out.println("Failed");
            return 0;
        }

    } catch (Exception e) {
        System.out.println(e.getMessage());
        return 0;
    }
}

    public List<String> getAllVehicleTypes() {
        List<String> allVehicleTypes = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            String query = "SELECT DISTINCT type FROM vehicle " +
                           "WHERE availabilitystatus = 'Available'";

            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                String vehicleType = resultSet.getString("type");
                allVehicleTypes.add(vehicleType);
            }

            resultSet.close();
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return allVehicleTypes;
    }

    public List<Integer> getDistinctSeatingCapacities() {
        List<Integer> distinctSeatingCapacities = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            String query = "SELECT DISTINCT seatingcapacity FROM vehicle " +
                           "WHERE availabilitystatus = 'Available'";

            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                int seatingcapacity = resultSet.getInt("seatingcapacity");
                distinctSeatingCapacities.add(seatingcapacity);
            }

            resultSet.close();
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return distinctSeatingCapacities;
    }
   
    public List<Vehicle> searchrent_Vehicles(String type, Date startDate, Date endDate, Integer capacity, Double locx, Double locy) {
    List<Vehicle> matchingVehicles = new ArrayList<>();
    StringBuilder sql = new StringBuilder("SELECT v.*, va.locx, va.locy FROM vehicle v JOIN vehicleavailability va ON v.vehicleid = va.vehicleid WHERE v.availabilitystatus = 'Available'");

    // Add SQL conditions for each parameter independently.
    if (type != null) {
        sql.append(" AND v.type = ?");
    }
    if (startDate != null) {
        sql.append(" AND va.startdate <= ?");
    }
    if (endDate != null) {
        sql.append(" AND va.enddate >= ?");
    }
    if (capacity != null) {
        sql.append(" AND v.seatingcapacity = ?");
    }
    if (locx != null) {
        sql.append(" AND va.locx = ?");
    }
    if (locy != null) {
        sql.append(" AND va.locy = ?");
    }

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
         PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {

        int index = 1;
        if (type != null) {
            pstmt.setString(index++, type);
        }
        if (startDate != null) {
            pstmt.setDate(index++, new java.sql.Date(startDate.getTime()));
        }
        if (endDate != null) {
            pstmt.setDate(index++, new java.sql.Date(endDate.getTime()));
        }
        if (capacity != null) {
            pstmt.setInt(index++, capacity);
        }
        if (locx != null) {
            pstmt.setDouble(index++, locx);
        }
        if (locy != null) {
            pstmt.setDouble(index++, locy);
        }

        ResultSet resultSet = pstmt.executeQuery();
        while (resultSet.next()) {
            Vehicle vehicle = new Vehicle();
            vehicle.populateFromResultSet(resultSet);
            matchingVehicles.add(vehicle);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return matchingVehicles;
}
 
    public void populateFromResultSet(ResultSet resultSet) throws SQLException {
        this.vehicleid = resultSet.getInt("vehicleid");
        this.ownerdriverid = resultSet.getInt("ownerdriverid");
        this.registrationno = resultSet.getString("registrationno");
        this.type = resultSet.getString("type");
        this.make = resultSet.getString("make");
        this.model = resultSet.getString("model");
        this.seatingcapacity = resultSet.getInt("seatingcapacity");
        this.rentalrateperday = resultSet.getDouble("rentalrateperday");
        this.availabilitystatus = resultSet.getString("availabilitystatus");
        this.locx = resultSet.getDouble("locx");
        this.locy = resultSet.getDouble("locy");
    }

    public String getDetails() {
    StringBuilder sb = new StringBuilder();
    sb.append("<table border='1' style='border-collapse: collapse; width: 100%;'>"); // Added inline styles
    sb.append("<tr style='background-color: #f2f2f2;'><th>Vehicle ID</th><td>").append(vehicleid).append("</td></tr>");
    sb.append("<tr><th>Owner/Driver ID</th><td>").append(ownerdriverid).append("</td></tr>");
    sb.append("<tr style='background-color: #f2f2f2;'><th>Registration No</th><td>").append(registrationno).append("</td></tr>");
    sb.append("<tr><th>Type</th><td>").append(type).append("</td></tr>");
    sb.append("<tr style='background-color: #f2f2f2;'><th>Make</th><td>").append(make).append("</td></tr>");
    sb.append("<tr><th>Model</th><td>").append(model).append("</td></tr>");
    sb.append("<tr style='background-color: #f2f2f2;'><th>Seating Capacity</th><td>").append(seatingcapacity).append("</td></tr>");
    sb.append("<tr><th>Rental Rate Per Day</th><td>").append(String.format("₱%.2f", rentalrateperday)).append("</td></tr>"); // Formatted as currency
    sb.append("<tr style='background-color: #f2f2f2;'><th>Availability Status</th><td>")
      .append(availabilitystatus.equals("Available") ? "<span style='color: green;'>Available</span>" : "<span style='color: red;'>Unavailable</span>")
      .append("</td></tr>"); // Conditional formatting
    sb.append("<tr><th>Location X</th><td>").append(locx).append("</td></tr>");
    sb.append("<tr style='background-color: #f2f2f2;'><th>Location Y</th><td>").append(locy).append("</td></tr>");
    sb.append("</table>");

    return sb.toString();
}
 
    public int registerNewCustomer(String firstname, String lastname, String email, String phone_no, String street, String province, String city_municipality, int zipcode, String country) {
    int newCustomerId = -1;
    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678")) {
        // Check the next available customer ID
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT MAX(customerid) + 1 AS newID FROM customer")) {
            if (rs.next()) {
                newCustomerId = rs.getInt("newID");
            }
            if (newCustomerId <= 0) {
                // If newCustomerId is 0 or less, there was a problem getting the ID
                throw new SQLException("Unable to retrieve new customer ID.");
            }
            // Insert the new customer
            try (PreparedStatement pstmt = conn.prepareStatement("INSERT INTO customer (customerid, firstname, lastname, email, phone_no, street, province, city_municipality, zipcode, country) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                pstmt.setInt(1, newCustomerId);
                pstmt.setString(2, firstname);
                pstmt.setString(3, lastname);
                pstmt.setString(4, email);
                pstmt.setString(5, phone_no);
                pstmt.setString(6, street);
                pstmt.setString(7, province);
                pstmt.setString(8, city_municipality);
                pstmt.setInt(9, zipcode);
                pstmt.setString(10, country);
                pstmt.executeUpdate();
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        newCustomerId = -1;
    }
    return newCustomerId; // Will return the new customer ID or -1 if there was an error
}

    public Customer verifyCustomer(int customerId) {
        Customer customer = null;
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/VRM", "root", "12345678");
             PreparedStatement pstmt = conn.prepareStatement(
                "SELECT * FROM customer WHERE customerid = ?")) {

            pstmt.setInt(1, customerId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    customer = new Customer();
                    customer.setCustomerid(rs.getInt("customerid"));
                    customer.setFirstname(rs.getString("firstname"));
                    customer.setLastname(rs.getString("lastname"));
                    customer.setEmail(rs.getString("email"));
                    customer.setPhone_no(rs.getString("phone_no"));
                    customer.setStreet(rs.getString("street"));
                    customer.setProvince(rs.getString("province"));
                    customer.setCity_municipality(rs.getString("city_municipality"));
                    customer.setZipcode(rs.getInt("zipcode"));
                    customer.setCountry(rs.getString("country"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }
   
    public int saveReservation(int customerid, int vehicleid, java.sql.Date startdate, java.sql.Date enddate, double totalCost) {
    int reservationId = -1;

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678")) {

        conn.setAutoCommit(false);
        
        String maxIdQuery = "SELECT MAX(reservationid) + 1 AS newID FROM rentalreservations";
        try (PreparedStatement maxIdStmt = conn.prepareStatement(maxIdQuery)) {
            ResultSet rs = maxIdStmt.executeQuery();
            if (rs.next()) {
                reservationId = rs.getInt("newID");
            }
            if (reservationId <= 0) {
                throw new SQLException("Unable to retrieve new reservation ID.");
            }
        }

        String insertReservationQuery = "INSERT INTO rentalreservations (reservationid, customerid, vehicleid, rentalstartdate, rentalenddate, totalcost) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement insertStmt = conn.prepareStatement(insertReservationQuery)) {
            insertStmt.setInt(1, reservationId);
            insertStmt.setInt(2, customerid);
            insertStmt.setInt(3, vehicleid);
            insertStmt.setDate(4, startdate);
            insertStmt.setDate(5, enddate);
            insertStmt.setDouble(6, totalCost);

            int affectedRows = insertStmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating reservation failed, no rows affected.");
            }

            conn.commit();
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
            throw e;
        }
        
    } catch (SQLException e) {
        e.printStackTrace();
        reservationId = -1;
    }
    return reservationId;
}

    public double calculateTotalCost(int vehicleid, java.sql.Date startdate, java.sql.Date enddate) {
        double totalCost = 0.0;
        String query = "SELECT rentalrateperday FROM vehicle WHERE vehicleid = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, vehicleid);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                double dailyRate = rs.getDouble("rentalrateperday");
                long diffInMillis = enddate.getTime() - startdate.getTime();
                long diffInDays = (diffInMillis / (1000 * 60 * 60 * 24)) + 1; // Including both start and end dates
                totalCost = dailyRate * diffInDays;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return totalCost;
    }

    public boolean updateVehicleAvailability(int vehicleid, String status) {
        boolean isUpdated = false;
        String query = "UPDATE vehicle SET availabilitystatus = ? WHERE vehicleid = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, status);
            stmt.setInt(2, vehicleid);

            int rowsAffected = stmt.executeUpdate();
            isUpdated = rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isUpdated;
    }

    public Reservation getReservationDetails(int reservationId) {
    String query = "SELECT * FROM rentalreservations WHERE reservationid = ?";
    Reservation reservation = null;

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setInt(1, reservationId);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            reservation = new Reservation(
                rs.getInt("reservationid"),
                rs.getInt("customerid"),
                rs.getInt("vehicleid"),
                rs.getDate("rentalstartdate"),
                rs.getDate("rentalenddate"),
                rs.getDouble("totalcost")
            );
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return reservation;
}
    
    public boolean updateReservation(int reservationId, int customerId, int vehicleId, java.sql.Date startDate, java.sql.Date endDate, double totalCost) {
    boolean updateStatus = false;

    String vehicleQuery = "SELECT COUNT(1) FROM vehicle WHERE vehicleid = ?";
    String customerQuery = "SELECT COUNT(1) FROM customer WHERE customerid = ?";
    String updateQuery = "UPDATE rentalreservations SET customerid = ?, vehicleid = ?, rentalstartdate = ?, rentalenddate = ?, totalcost = ? WHERE reservationid = ?";

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
         PreparedStatement vehicleStmt = conn.prepareStatement(vehicleQuery);
         PreparedStatement customerStmt = conn.prepareStatement(customerQuery);
         PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
        
        // Check if the vehicle exists
        vehicleStmt.setInt(1, vehicleId);
        ResultSet vehicleRs = vehicleStmt.executeQuery();
        if (!vehicleRs.next() || vehicleRs.getInt(1) == 0) {
            return false; // Vehicle does not exist
        }
        
        // Check if the customer exists
        customerStmt.setInt(1, customerId);
        ResultSet customerRs = customerStmt.executeQuery();
        if (!customerRs.next() || customerRs.getInt(1) == 0) {
            return false; // Customer does not exist
        }

        // Both vehicle and customer exist, proceed with update
        conn.setAutoCommit(false); // Start transaction
        updateStmt.setInt(1, customerId);
        updateStmt.setInt(2, vehicleId);
        updateStmt.setDate(3, startDate);
        updateStmt.setDate(4, endDate);
        updateStmt.setDouble(5, totalCost);
        updateStmt.setInt(6, reservationId);

        int affectedRows = updateStmt.executeUpdate();
        if (affectedRows > 0) {
            updateStatus = true;
        }

        conn.commit(); // Commit transaction
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return updateStatus;
}
    
    public boolean isAvailable(int vehicleId, java.sql.Date userStartDate, java.sql.Date userEndDate, Connection conn) {
    String query = "SELECT COUNT(*) AS affected_reservations " +
                   "FROM rentalreservations " +
                   "WHERE vehicleid = ? AND " +
                   "((? IS NOT NULL AND rentalstartdate <= ? AND rentalenddate >= ?) OR " +
                   "(? IS NULL AND ? IS NOT NULL AND rentalstartdate <= ? AND rentalenddate >= ?) OR " +
                   "(? IS NOT NULL AND ? IS NOT NULL AND " +
                   "((rentalstartdate BETWEEN ? AND ?) OR (rentalenddate BETWEEN ? AND ?))))";

    try (PreparedStatement pstmt = conn.prepareStatement(query)) {
        // Set the vehicle ID parameter
        pstmt.setInt(1, vehicleId);

        // Set the parameters for the query
        pstmt.setDate(2, userStartDate);
        pstmt.setDate(3, userStartDate);
        pstmt.setDate(4, userStartDate);
        pstmt.setDate(5, userStartDate);
        pstmt.setDate(6, userEndDate);
        pstmt.setDate(7, userEndDate);
        pstmt.setDate(8, userEndDate);
        pstmt.setDate(9, userStartDate);
        pstmt.setDate(10, userEndDate);
        pstmt.setDate(11, userStartDate);
        pstmt.setDate(12, userEndDate);
        pstmt.setDate(13, userStartDate);
        pstmt.setDate(14, userEndDate);

        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                // Check if the count of affected reservations is zero
                return rs.getInt("affected_reservations") == 0;
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return false; // Default to not available in case of an error or no data found
}
    
    public int checkEndDateSurpasses(java.sql.Date userEndDate) {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM vehicleavailability WHERE ? > enddate";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDate(1, userEndDate);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    count = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }
    
    public int checkEnddate(int vehicleId, java.sql.Date userEndDate) {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM rentalreservations WHERE vehicleid = ? AND ? BETWEEN rentalstartdate AND rentalenddate";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, vehicleId);
            pstmt.setDate(2, userEndDate);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    count = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }
    
    public boolean hasConflictsWithOtherVehicles(Connection conn, int reservationId, int vehicleId, Date newStartDate, Date newEndDate) throws SQLException {
    boolean hasConflicts = false;

    // Get the existing reservation's start and end dates
    Date existingStartDate = getReservationStartDate(reservationId);
    Date existingEndDate = getReservationEndDate(reservationId);

    // Determine which dates have changed
    boolean startDateChanged = !newStartDate.equals(existingStartDate);
    boolean endDateChanged = !newEndDate.equals(existingEndDate);

    // Check for conflicts based on the changed date
    if (startDateChanged) {
        hasConflicts = hasConflictsForStartDate(conn, reservationId, vehicleId, newStartDate, newEndDate);
    } else if (endDateChanged) {
        hasConflicts = hasConflictsForEndDate(conn, reservationId, vehicleId, newStartDate, newEndDate);
    }

    return hasConflicts;
}

    private boolean hasConflictsForStartDate(Connection conn, int reservationId, int vehicleId, Date newStartDate, Date newEndDate) throws SQLException {
    String query = "SELECT COUNT(*) FROM rentalreservations " +
                   "WHERE vehicleid = ? " + // Only check for conflicts for the same vehicle
                   "AND reservationid != ? " + // Exclude the current reservation
                   "AND ? < rentalenddate " + // New start date is before existing end date
                   "AND ? >= rentalstartdate"; // New start date is on or after existing start date
    
    try (PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setInt(1, vehicleId);
        pstmt.setInt(2, reservationId);
        pstmt.setDate(3, newStartDate);
        pstmt.setDate(4, newStartDate);
        
        try (ResultSet resultSet = pstmt.executeQuery()) {
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        throw e;
    }
    
    return false;
}

    private boolean hasConflictsForEndDate(Connection conn, int reservationId, int vehicleId, Date newStartDate, Date newEndDate) throws SQLException {
    String query = "SELECT COUNT(*) FROM rentalreservations " +
                   "WHERE vehicleid = ? " + // Only check for conflicts for the same vehicle
                   "AND reservationid != ? " + // Exclude the current reservation
                   "AND ? <= rentalenddate " + // New end date is on or before existing end date
                   "AND ? > rentalstartdate"; // New end date is after existing start date
    
    try (PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setInt(1, vehicleId);
        pstmt.setInt(2, reservationId);
        pstmt.setDate(3, newEndDate);
        pstmt.setDate(4, newEndDate);
        
        try (ResultSet resultSet = pstmt.executeQuery()) {
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        throw e;
    }
    
    return false;
}

    public Date getReservationStartDate(int reservationId) throws SQLException {
        Date startDate = null;
        String query = "SELECT rentalstartdate FROM rentalreservations WHERE reservationid = ?";
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, reservationId);
            
            try (ResultSet resultSet = pstmt.executeQuery()) {
                if (resultSet.next()) {
                    startDate = resultSet.getDate("rentalstartdate");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        
        return startDate;
    }
    
    public Date getReservationEndDate(int reservationId) throws SQLException {
        Date endDate = null;
        String query = "SELECT rentalenddate FROM rentalreservations WHERE reservationid = ?";
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, reservationId);
            
            try (ResultSet resultSet = pstmt.executeQuery()) {
                if (resultSet.next()) {
                    endDate = resultSet.getDate("rentalenddate");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        
        return endDate;
    }
    
    public String getVehicleAvailabilityStatus(int vehicleId) {
        String sql = "SELECT availabilitystatus FROM vehicle WHERE vehicleid = ?";
        

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, vehicleId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("availabilitystatus");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Optionally, rethrow the exception or handle it as per your application's error handling policy
            // throw e;
        }
        return null; // Return null or consider throwing an exception if the vehicle is not found
    }
    
    // Getters and setters
    public int getVehicleid() {
        return vehicleid;
    }

    public void setVehicleid(int vehicleid) {
        this.vehicleid = vehicleid;
    }

    public int getOwnerdriverid() {
        return ownerdriverid;
    }

    public void setOwnerdriverid(int ownerdriverid) {
        this.ownerdriverid = ownerdriverid;
    }

    public String getRegistrationno() {
        return registrationno;
    }

    public void setRegistrationno(String registrationno) {
        this.registrationno = registrationno;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getSeatingcapacity() {
        return seatingcapacity;
    }

    public void setSeatingcapacity(int seatingcapacity) {
        this.seatingcapacity = seatingcapacity;
    }

    public double getRentalrateperday() {
        return rentalrateperday;
    }

    public void setRentalrateperday(double rentalrateperday) {
        this.rentalrateperday = rentalrateperday;
    }

    public String getAvailabilitystatus() {
        return availabilitystatus;
    }

    public void setAvailabilitystatus(String availabilitystatus) {
        this.availabilitystatus = availabilitystatus;
    }
    
    public double getLocx() {
        return locx;
    }

    public void setLocx(double locx) {
        this.locx = locx;
    }

    public double getLocy() {
        return locy;
    }

    public void setLocy(double locy) {
        this.locy = locy;
    }
     
    @Override
    public String toString() {

    StringBuilder sb = new StringBuilder();
    sb.append("\tOwner Driver ID: ").append(ownerdriverid).append("<br>");
    sb.append("\tRegistration No: ").append(registrationno).append("<br>");
    sb.append("\tType: ").append(type).append("<br>");
    sb.append("\tMake: ").append(make).append("<br>");
    sb.append("\tModel: ").append(model).append("<br>");
    sb.append("\tSeating Capacity: ").append(seatingcapacity).append("<br>");
    sb.append("\tRental Rate Per Day: ").append(rentalrateperday).append("<br>");
    sb.append("\tAvailability Status: ").append(availabilitystatus).append("<br>");

    return sb.toString();

}
    
       public static void main(String[] args) {

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/DDL SCRIPT?user=root&password=12345678")) {
            Vehicle vehicle = new Vehicle(); // Assuming Vehicle is your class with the method

            int reservationId = 3601; // Replace with an actual reservation ID
            int vehicleId = 1; // Replace with an actual vehicle ID
            Date newStartDate = Date.valueOf("2023-11-23"); // Replace with a valid start date
            Date newEndDate = null; // Replace with a valid end date

            boolean hasConflicts = vehicle.hasConflictsWithOtherVehicles(conn, reservationId, vehicleId, newStartDate, newEndDate);

            if (hasConflicts) {
                System.out.println("There are conflicts with other reservations.");
            } else {
                System.out.println("No conflicts found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}