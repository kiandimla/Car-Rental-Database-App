package VehicleRentalManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerUtil {
    public static int getNextCustomerID(Connection conn) {
        int newID = 0;
        PreparedStatement pstmt = null;
        ResultSet rst = null;

        try {
            pstmt = conn.prepareStatement("SELECT MAX(customerid) + 1 AS newID FROM customer");
            rst = pstmt.executeQuery();

            while (rst.next()) {
                newID = rst.getInt("newID");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the resources
            try {
                if (rst != null) {
                    rst.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return newID;
    }
}
