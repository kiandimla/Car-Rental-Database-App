package VehicleRentalManagement;

import java.sql.*;
import java.util.*;

public class VehicleManagement {
    public int vehicleid;
    public int rentalreservationcount;
    public String type;
    public String make;
    public String model;
    public String startdate;
    public String enddate;

    public List<Map<String, Object>> generateVehicleReport(String vehicleType, String make, String model, String startDate, String endDate) {
        List<Map<String, Object>> reportData = new ArrayList<>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/VRM?user=root&password=12345678");
            System.out.println("Connection Successful");

            StringBuilder sqlBuilder = new StringBuilder("SELECT v.make, v.model, v.type, " +
                    "COUNT(rentalreservations.reservationid) AS rentalreservationcount " +
                    "FROM vehicle v " +
                    "LEFT JOIN rentalreservations ON v.vehicleid = rentalreservations.vehicleid " +
                    "WHERE 1 = 1 ");

            List<Object> params = new ArrayList<>();

            if (!vehicleType.equals("Select")) {
                sqlBuilder.append("AND v.type = ? ");
                params.add(vehicleType);
            }

            if (!make.equals("Select")) {
                sqlBuilder.append("AND v.make = ? ");
                params.add(make);
            }

            if (!model.equals("Select")) {
                sqlBuilder.append("AND v.model = ? ");
                params.add(model);
            }

            if (startDate != null && !startDate.isEmpty()) {
                sqlBuilder.append("AND rentalreservations.rentalstartdate >= ? ");
                params.add(startDate);
            }

            if (endDate != null && !endDate.isEmpty()) {
                sqlBuilder.append("AND rentalreservations.rentalstartdate <= ? ");
                params.add(endDate);
            } else {
                java.sql.Date today = new java.sql.Date(System.currentTimeMillis());
                sqlBuilder.append("AND rentalreservations.rentalstartdate <= ? ");
                params.add(today.toString());
            }

            sqlBuilder.append("GROUP BY v.make, v.model, v.type ");
            sqlBuilder.append("ORDER BY rentalreservationcount DESC");

            PreparedStatement stmt = conn.prepareStatement(sqlBuilder.toString());

            int paramIndex = 1;
            for (Object param : params) {
                stmt.setObject(paramIndex++, param);
            }

            ResultSet resultSet = stmt.executeQuery();

            int totalReservationCount = 0;

            while (resultSet.next()) {
                Map<String, Object> entry = new HashMap<>();
                entry.put("make", resultSet.getString("make"));
                entry.put("model", resultSet.getString("model"));
                entry.put("type", resultSet.getString("type"));
                entry.put("rentalreservationcount", resultSet.getInt("rentalreservationcount"));
                reportData.add(entry);
                
                totalReservationCount += resultSet.getInt("rentalreservationcount");
            }
            
            System.out.println("Total Reservation Count: " + totalReservationCount);

            resultSet.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return reportData;
    }

    public int getTotalReservationCount(List<Map<String, Object>> reportData) {
        int totalReservationCount = 0;
        for (Map<String, Object> entry : reportData) {
            totalReservationCount += (int) entry.get("rentalreservationcount");
        }
        return totalReservationCount;
    }
}
